var B1HSL_SessionID ="";
var B1HSL_RouteID = "";
var MetadataJSONData;
var ItemsJSONData;
var LastItemIndex= 0;
var selectedOrder= 0;
var ordersList = null;