var SessionID = "";

sap.ui.controller("SLFiori.view.Dashboard", {

	onInit: function() {

		this.router = sap.ui.core.UIComponent.getRouterFor(this);
		this.router.attachRoutePatternMatched(this._handleRouteMatched, this);
		// 		var Session1="";
		// 		Session1 = data.mParameters.arguments.Session;

		var head = document.getElementsByTagName('head')[0];
		var link = document.createElement('link');
		link.rel = "stylesheet";
		head.appendChild(link);

		this.list = {

			CustomerList: [

                                       ],

			ListData: [
				{
					listName: "Grant Code(Funding Source Code)"
				},
				{
					listName: "Parent Program"
				},
				{
					listName: "Program Master"
				},
				{
					listName: "Grant Initiative"
				},
				{
					listName: "Donor Master"
				}
                  ],

			TransactionsData: [
                            	//{listName:"Grant Master Request"},
				{
					listName: "Grant Contract"
				},
				{
					listName: "Grant Allocation"
				},
				{
					listName: "Grant Freezing"
				},
				{
					listName: "Cash Request"
				},
				{
					listName: "Grant Freezing Period"
				},
				{
					listName: "Grant Closing"
				}
                  ],

			ReportsData: [
				{
					listName: "Grant Summary Report"
				},
				{
					listName: "Grant Status Report"
				},
				{
					listName: "Grant Report for Donor"
				}
                  ],

			EmpData: [
				{
					listName: "Reimbursement"
				}

                  ]

		};

		this.oModel = new sap.ui.model.json.JSONModel(this.list);
		this.getView().setModel(this.oModel);
	},

	onAfterRendering: function() {
		//this.byId("idProductsTable").setWidths(["30%", "70%"]);
	},

	_handleRouteMatched: function(data) {

		// if (data.mParameters.arguments.Session !== "0"){
		//     var Session="";
		//     Session = data.mParameters.arguments.Session;    
		// } else{
		//     Session = Session;
		// }
		SessionID = data.mParameters.arguments.Session;
	},

	onMastersSelectionChange: function(oEvent) {
		var oList = this.byId("Masters");
		var oSelectedItem = oList.getSelectedItem().mProperties.title;

		if (oSelectedItem === "Grant Code(Funding Source Code)") {
			var that = this;
			oSelectedItem = oList.getSelectedItem();
			oList.setSelectedItem(oSelectedItem, false);
			this.handleCostCentersList();
			//that.router.navTo("masters.grantcode");
		} else if (oSelectedItem === "Parent Program") {
			oSelectedItem = oList.getSelectedItem();
			oList.setSelectedItem(oSelectedItem, false);
			this.handleParentProgramList();
		} else if (oSelectedItem === "Program Master") {
			oSelectedItem = oList.getSelectedItem();
			oList.setSelectedItem(oSelectedItem, false);
			this.handleProgramCodeList();
		} else if (oSelectedItem === "Grant Initiative") {
			oSelectedItem = oList.getSelectedItem();
			oList.setSelectedItem(oSelectedItem, false);
			this.handleGrantInitiativeList();
		} else if (oSelectedItem === "Donor Master") {
			oSelectedItem = oList.getSelectedItem();
			oList.setSelectedItem(oSelectedItem, false);
			this.handleDonorMaster();
		}
	},

	onTransactionsSelectionChange: function(oEvent) {
		var oList = this.byId("Transactions");
		var oSelectedItem = oList.getSelectedItem().mProperties.title;

		if (oSelectedItem == "Grant Master Request") {

		} else if (oSelectedItem == "Grant Contract") {
			var that = this;
			oSelectedItem = oList.getSelectedItem();
			oList.setSelectedItem(oSelectedItem, false); // This action deselects item and allow you select the item again
			this.handleGrantList();
		} else if (oSelectedItem == "Grant Allocation") {
			var that = this;
			oSelectedItem = oList.getSelectedItem();
			oList.setSelectedItem(oSelectedItem, false); // This action deselects item and allow you select the item again

			//that.router.navTo("GrantAllocation");
		} else if (oSelectedItem == "Grant Freezing") {
			var that = this;
			//this.handleGrantFreezing();
			oSelectedItem = oList.getSelectedItem();
			oList.setSelectedItem(oSelectedItem, false); // This action deselects item and allow you select the item again
			//that.router.navTo("GrantFreezing");
		} else if (oSelectedItem == "Cash Request") {
			var that = this;
			//this.handleGrantFreezing();
			oSelectedItem = oList.getSelectedItem();
			oList.setSelectedItem(oSelectedItem, false); // This action deselects item and allow you select the item again
			that.router.navTo("CashRequest");
		} else if (oSelectedItem == "Grant Freezing Period") {

		} else if (oSelectedItem == "Grant Closing") {

		}
	},

	onReportsSelectionChange: function(oEvent) {
		var oList = this.byId("Reports");
		var oSelectedItem = oList.getSelectedItem().mProperties.title;

		if (oSelectedItem == "Grant Summary Report") {

		} else if (oSelectedItem == "Grant Status Report") {

		} else if (oSelectedItem == "Grant Report for Donor") {

		}
	},

	onEmpSelectionChange: function(oEvent) {
		var oList = this.byId("Employee");
		var oSelectedItem = oList.getSelectedItem().mProperties.title;

		if (oSelectedItem == "Reimbursement") {

		} else if (oSelectedItem == "") {

		} else if (oSelectedItem == "") {

		}
	},

	handleGrantContract: function() {
		var that = this;
		this.handleGrantList();
	},

	handleGrantList: function(oEvent) {
		var that = this;
		if (!this.oGetGrantDialog) {
			this.oGetGrantDialog = sap.ui.xmlfragment("SLFiori/fragments.GetGrantListV3", this);
		}
		sap.ui.getCore().byId("GetGrantTable").removeSelections();
		this.oGetGrantDialog.setModel(this.oModel);
		$.ajax({
			//url: "https://172.31.28.160:50000/b1s/v1/BusinessPartners?$select=CardCode,CardName&$filter=CardType eq 'C'",
			//url: "http://172.31.28.160:8000/CustomControls_v1/SAPUI5/WebContent/org/edu/ui/OData/BP.xsodata/BusinessPartner",
			//url: "http://10.0.1.189:8000/Ashoka/SAPUI5/WebContent/org/edu/ui/OData/GrantContract_GrantList.xsodata/GrantContract",
			url: "OData/GrantContract_GrantList.xsodata/GrantContract",
			xhrFields: {
				withCredentials: true
			},
			async: false,
			type: "GET",
			dataType: "json",
			success: function(oData, oResponse) {
				that.oModel.getData().GrantList = oData.d.results;
				that.oModel.refresh();
				that.oGetGrantDialog.open();
			},
			error: function(oError) {
				sap.m.MessageToast.show("Error: " + oError);
			}
		});
	},

	handleGrantOk: function(oEvent) {
		var that = this;
		var oGetGrantListTable = sap.ui.getCore().byId("GetGrantTable");
		var oSelectedGrant = oGetGrantListTable.getSelectedItem();
		if (oSelectedGrant) {
			var oSelctedCustContext = oSelectedGrant.getBindingContext();
			var path = oSelctedCustContext.sPath;
			var GrantDocNum = this.oModel.getProperty(path);
			this.oGetGrantDialog.close();
			that.router.navTo("GrantContract", {
				Key: GrantDocNum.DocEntry
			});
		} else {
			this.oGetGrantDialog.close();
			that.router.navTo("GrantContract", {
				Key: 1
			});
		}
	},

	handleNewGrantCode: function() {
		var that = this;
		this.oDialog.close();
		that.router.navTo("masters.grantcode", {
			Key: 0
		});
	},

	handleAddEntry: function(oEvent) {
		var that = this;
		var oGetGrantListTable = sap.ui.getCore().byId("GetGrantTable");
		//var oSelectedGrant= oGetGrantListTable.getSelectedItem();

		this.oGetGrantDialog.close();
		that.router.navTo("GrantContract", {
			Key: 0
		});

	},

	handlelogoffButton: function(oEvent) {
		//this.router.navTo("GrantContract");
		var that = this;
		var jDataLogout = JSON.stringify({
			UserName: "manager",
			Password: "manager",
			CompanyDB: "SBODEMOUS"
		});

		//   $.ajax({
		//     		type: "POST",
		//     		url: "/sap/sbo/platform/login?$func=logout",
		//     // 		headers: {
		//     // 		//	"Authorization": "Basic " + btoa("SYSTEM" + ":" + "Ashoka@123")
		//     // 		},
		//     		beforeSend: function(xhr) {
		//     			xhr.setRequestHeader("X-CSRF-Token", "Fetch");
		//     		},
		//     // 		data: {
		//     // // 			"company": "SBODEMOUS",
		//     // // 			"username": "manager",
		//     // // 			"password": "manager",
		//     // // 			"language": "en-US"
		//     // 		},
		//     		error: function(xhr, status, error) 
		//     		{

		//     			  var data = JSON.parse(xhr.responseText);
		//     		      window.alert("Login failed: " +data['msg']);
		//     		},
		//     		success: function(json, textStatus, XMLHttpRequest) {
		//     			//$("#wait").css("display", "none");
		//     			console.log("Success");
		//     			//login_service(user.value, pass.value);
		//     		}
		//     	});

		$.ajax({
			//url: "https://10.0.1.189:50000/b1s/v1/Logout",
			url: "/b1s/v1/Logout",
			xhrFields: {
				withCredentials: true
			},
			//data: jDataLogout,
			type: "POST",
			dataType: "json",
			data: {
				"SessionTimeout": "0"
			},
			success: function(jDataLogout) {
				that.router.navTo("Login");
				console.log("Logged out Succesfully");
			},
			error: function(xhr, status, errorThrown) {
				sap.m.MessageToast.show("Error: " + errorThrown);
			},
			complete: function(xhr, status) {}
		});
	},

	handleGrantClose: function() {
		sap.ui.getCore().byId("GetGrantTable").removeSelections();
		this.oGetGrantDialog.close();
	},

	onCollapseExapandPress: function() {
		var sideNavigation = this.getView().byId('sideNavigation');
		var expanded = !sideNavigation.getexpanded();

		sideNavigation.setExpanded(expanded);
	},

	handleDonorMaster: function(oEvent) {
		var that = this;
		if (!this.oCustomerMasterDialog) {
			//			this.oCustomerMasterDialog = sap.ui.xmlfragment("SLFiori.fragments.CustomerMaster",this);
			this.oCustomerMasterDialog = sap.ui.xmlfragment("SLFiori.fragments.DonorMasterV3", this);
		}
		sap.ui.getCore().byId("DonorListTable").removeSelections();
		this.oCustomerMasterDialog.setModel(this.oModel);
		$.ajax({

			//url: "/b1s/v1/BusinessPartners?$select=CardCode,CardName,ContactPerson,Cellular,EmailAddress&$filter=Valid eq 'Y' and Frozen eq 'N' and CardType eq 'C' &$top=1000 &$orderby=CardName",
			url: "OData/GrantContract_BP.xsodata/CardCode",

			xhrFields: {
				withCredentials: false
			},
// 			beforeSend: function(xhr) {
// 				xhr.setRequestHeader("B1SESSION", SessionID);
// 			},
			async: false,
			type: "GET",
			dataType: "json",
			success: function(oData, oResponse) {
				that.oModel.getData().DonorList = oData.d.results;//oData.value;
				that.oModel.refresh();
				that.oCustomerMasterDialog.open();
			},
			error: function(oError) {
				sap.m.MessageToast.show("Error: " + oError);
			}
		});
	},

	handleCustOk: function(oEvent) {
		//this.oCustomerMasterDialog.close();
		//this.router.navTo("DonorMaster");

		var that = this;
		var oDonorListTable = sap.ui.getCore().byId("DonorListTable");
		var oSelectedGrant = oDonorListTable.getSelectedItem();
		if (oSelectedGrant) {
			var oSelctedCustContext = oSelectedGrant.getBindingContext();
			var path = oSelctedCustContext.sPath;
			var DonorCode = this.oModel.getProperty(path);
			this.oCustomerMasterDialog.close();
			that.router.navTo("DonorMaster", {
				Key: DonorCode.CardCode
			});
		} else {
			//this.oCustomerMasterDialog.close();
			//that.router.navTo("DonorMaster",{Key:1});
			sap.m.MessageToast.show("Please select Donor");
		}
	},

	handleCustClose: function() {
		sap.ui.getCore().byId("DonorListTable").removeSelections();
		this.oCustomerMasterDialog.close();
	},

	handleAddNewDonor: function(oEvent) {
		var that = this;
		this.oCustomerMasterDialog.close();
		that.router.navTo("DonorMaster", {
			Key: 0
		});
	},

	handleCostCentersList: function(oEvent) {
		var that = this;
		if (!this.oDialog) {
			this.oDialog = sap.ui.xmlfragment("SLFiori.fragments.CostCentersV7", this);
		}
		sap.ui.getCore().byId("CostCentersListTable").removeSelections();
		this.oDialog.setModel(this.oModel);
		$.ajax({
			//url: "http://10.0.1.189:8000/Ashoka/SAPUI5/WebContent/org/edu/ui/OData/CostCenter.xsodata/CostCenter?$filter=DMCode eq '1'",
			url: "OData/CostCenter.xsodata/CostCenter?$filter=DMCode eq '1'",
			xhrFields: {
				withCredentials: true
			},
			async: false,
			type: "GET",
			dataType: "json",
			success: function(oData, oResponse) {
				that.oModel.getData().CostCentersList = oData.d.results; //oData.value;
				that.oModel.refresh();
				that.oDialog.open();
			},
			error: function(oError) {
				sap.m.MessageToast.show("Error: " + oError);
			}
		});
	},

	handleCostCentersOk: function(oEvent) {
		//this.oDialog.close();

		var that = this;
		var oDonorListTable = sap.ui.getCore().byId("CostCentersListTable");
		var oSelectedGrant = oDonorListTable.getSelectedItem();
		if (oSelectedGrant) {
			var oSelctedCustContext = oSelectedGrant.getBindingContext();
			var path = oSelctedCustContext.sPath;
			var DonorCode = this.oModel.getProperty(path);
			this.oDialog.close();
			that.router.navTo("masters.grantcode", {
				Key: DonorCode.CCCode
			});
		} else {
			//this.oCustomerMasterDialog.close();
			//that.router.navTo("DonorMaster",{Key:1});
			sap.m.MessageToast.show("Please select Donor");
		}
	},

	handleCostCentersClose: function(oEvent) {
		this.oDialog.close();
		//this.router.navTo("DonorMaster");
	},

	handleProgramCodeList: function(oEvent) {
		var that = this;
		if (!this.oProgramCodeDialog) {
			this.oProgramCodeDialog = sap.ui.xmlfragment("SLFiori.fragments.ProgramCodeV2", this);
		}
		sap.ui.getCore().byId("ProgramCodeListTable").removeSelections();
		this.oProgramCodeDialog.setModel(this.oModel);
		$.ajax({
			//        		url: "http://10.0.1.189:8000/Ashoka/SAPUI5/WebContent/org/edu/ui/OData/CostCenter.xsodata/CostCenter?$filter=DMCode eq '4'",
			url: "OData/CostCenter.xsodata/CostCenter?$filter=DMCode eq '4'",
			xhrFields: {
				withCredentials: true
			},
			async: false,
			type: "GET",
			dataType: "json",
			success: function(oData, oResponse) {
				that.oModel.getData().ProgramCodeList = oData.d.results; //oData.value;
				that.oModel.refresh();
				that.oProgramCodeDialog.open();
			},
			error: function(oError) {
				sap.m.MessageToast.show("Error: " + oError);
			}
		});
	},

	handleProgramCodeOk: function(oEvent) {
		//this.oProgramCodeDialog.close();

		var that = this;
		var oDonorListTable = sap.ui.getCore().byId("ProgramCodeListTable");
		var oSelectedGrant = oDonorListTable.getSelectedItem();
		if (oSelectedGrant) {
			var oSelctedCustContext = oSelectedGrant.getBindingContext();
			var path = oSelctedCustContext.sPath;
			var DonorCode = this.oModel.getProperty(path);
			this.oProgramCodeDialog.close();
			that.router.navTo("masters.programmaster", {
				Key: DonorCode.CCCode
			});
		} else {
			//this.oCustomerMasterDialog.close();
			//that.router.navTo("DonorMaster",{Key:1});
			sap.m.MessageToast.show("Please select Program Code");
		}
	},

	handleProgramCodeClose: function(oEvent) {
		this.oProgramCodeDialog.close();
		//this.router.navTo("DonorMaster");
	},

	handleAddProgramCode: function() {
		var that = this;
		this.oProgramCodeDialog.close();
		that.router.navTo("masters.programmaster", {
			Key: 0
		});
	},

	handleGrantInitiativeList: function(oEvent) {
		var that = this;
		if (!this.oGrantInitiativeDialog) {
			this.oGrantInitiativeDialog = sap.ui.xmlfragment("SLFiori.fragments.GrantInitiativeV1", this);
		}
		sap.ui.getCore().byId("GrantInitiativeTable").removeSelections();
		this.oGrantInitiativeDialog.setModel(this.oModel);
		$.ajax({
			//url: "http://10.0.1.189:8000/Ashoka/SAPUI5/WebContent/org/edu/ui/OData/CostCenter.xsodata/CostCenter?$filter=DMCode eq '5'",
			url: "OData/CostCenter.xsodata/CostCenter?$filter=DMCode eq '5'",
			xhrFields: {
				withCredentials: true
			},
			async: false,
			type: "GET",
			dataType: "json",
			success: function(oData, oResponse) {
				that.oModel.getData().GrantInitiativeList = oData.d.results; //oData.value;
				that.oModel.refresh();
				that.oGrantInitiativeDialog.open();
			},
			error: function(oError) {
				sap.m.MessageToast.show("Error: " + oError);
			}
		});
	},

	handleGrantInitiativeOk: function(oEvent) {
		this.oGrantInitiativeDialog.close();
		//this.router.navTo("DonorMaster");
	},

	handleGrantInitiativeClose: function(oEvent) {
		this.oGrantInitiativeDialog.close();
		//this.router.navTo("DonorMaster");
	},

	handleParentProgramList: function(oEvent) {
		var that = this;
		if (!this.oParentProgramDialog) {
			this.oParentProgramDialog = sap.ui.xmlfragment("SLFiori.fragments.ParentProgramv1", this);
		}
		sap.ui.getCore().byId("ParentProgramTable").removeSelections();
		this.oParentProgramDialog.setModel(this.oModel);
		$.ajax({
			url: "OData/ParentProgram.xsodata/ParentProgram",
			xhrFields: {
				withCredentials: true
			},
			async: false,
			type: "GET",
			dataType: "json",
			success: function(oData, oResponse) {
				that.oModel.getData().ParentProgramList = oData.d.results; //oData.value;
				that.oModel.refresh();
				that.oParentProgramDialog.open();
			},
			error: function(oError) {
				sap.m.MessageToast.show("Error: " + oError);
			}
		});
	},

	handleParentProgramOk: function(oEvent) {
		//this.oParentProgramDialog.close();
		var that = this;
		var oDonorListTable = sap.ui.getCore().byId("ParentProgramTable");
		var oSelectedGrant = oDonorListTable.getSelectedItem();
		if (oSelectedGrant) {
			var oSelctedCustContext = oSelectedGrant.getBindingContext();
			var path = oSelctedCustContext.sPath;
			var DonorCode = this.oModel.getProperty(path);
			this.oParentProgramDialog.close();
			// 			that.router.navTo("masters.programmaster", {
			// 				Key: DonorCode.CCCode
			// 			});
			var PgmCode = DonorCode.Code;
			if (!this.oAddParentProgramDialog) {
				this.oAddParentProgramDialog = sap.ui.xmlfragment("SLFiori.fragments.AddProgramCode", this);
			}
			//sap.ui.getCore().byId("ParentProgramTable").removeSelections();
			this.oAddParentProgramDialog.setModel(this.oModel);
			that.oAddParentProgramDialog.open();

			$.ajax({
				url: "/b1s/v1/IK_PPGM('" + PgmCode + "')",
				xhrFields: {
					withCredentials: true
				},
				async: false,
				type: "GET",
				dataType: "json",
				success: function(oData, oResponse) {

					that.oModel.setProperty("/FormMode", "Update");
					that.oModel.setProperty("/PrcCode", oData.Code);
					that.oModel.setProperty("/PrcName", oData.Name);

					that.oModel.refresh();
				},
				error: function(oError) {
					sap.m.MessageToast.show("Error: " + oError);
				}
			});
		} else {
			//this.oCustomerMasterDialog.close();
			//that.router.navTo("DonorMaster",{Key:1});
			sap.m.MessageToast.show("Please select Program Code");
		}

		//var oModelData = this.oModel.getData();
		//var that = this;

	},

	handleParentProgramClose: function(oEvent) {
		this.oParentProgramDialog.close();
		//this.router.navTo("DonorMaster");
	},

	handleAddParentPgm: function(oEvent) {

		var that = this;
		this.oParentProgramDialog.close();
		if (!this.oAddParentProgramDialog) {
			this.oAddParentProgramDialog = sap.ui.xmlfragment("SLFiori.fragments.AddProgramCode", this);
		}
		//sap.ui.getCore().byId("ParentProgramTable").removeSelections();
		this.oAddParentProgramDialog.setModel(this.oModel);
		that.oAddParentProgramDialog.open();

	},

	handleAddProgramCodeClose: function(oEvent) {
		this.oAddParentProgramDialog.close();
		//this.router.navTo("DonorMaster");
	},

	onSearch: function(oEvt) {
		var list = sap.ui.getCore().byId("DonorListTable"); //this.getView().byId("idList");
		var oBinding = list.getBinding("items");
		// add filter for search
		var aFilters = [];
		var sQuery = oEvt.getSource().getValue();
		if (sQuery && sQuery.length > 0) {
			var filter = new sap.ui.model.Filter("CardName", sap.ui.model.FilterOperator.Contains, sQuery);
			aFilters.push(filter);
		}
		oBinding.filter(aFilters);
	},
	
	onGrantListSearch: function(oEvt) {
		var list = sap.ui.getCore().byId("GetGrantTable"); //this.getView().byId("idList");
		var oBinding = list.getBinding("items");
		// add filter for search
		var aFilters = [];
		var sQuery = oEvt.getSource().getValue();
		if (sQuery && sQuery.length > 0) {
			var filter = new sap.ui.model.Filter("U_GName", sap.ui.model.FilterOperator.Contains, sQuery);
			aFilters.push(filter);
		}
		oBinding.filter(aFilters);
	},
	
	onDim1Search: function(oEvt) {
		var list = sap.ui.getCore().byId("CostCentersListTable"); //this.getView().byId("idList");
		var oBinding = list.getBinding("items");
		// add filter for search
		var aFilters = [];
		var sQuery = oEvt.getSource().getValue();
		if (sQuery && sQuery.length > 0) {
			var filter = new sap.ui.model.Filter("CCName", sap.ui.model.FilterOperator.Contains, sQuery);
			aFilters.push(filter);
		}
		oBinding.filter(aFilters);
	},
	
	onPgmCodeSearch: function(oEvt) {
		var list = sap.ui.getCore().byId("ProgramCodeListTable"); //this.getView().byId("idList");
		var oBinding = list.getBinding("items");
		// add filter for search
		var aFilters = [];
		var sQuery = oEvt.getSource().getValue();
		if (sQuery && sQuery.length > 0) {
			var filter = new sap.ui.model.Filter("CCName", sap.ui.model.FilterOperator.Contains, sQuery);
			aFilters.push(filter);
		}
		oBinding.filter(aFilters);
	}

});