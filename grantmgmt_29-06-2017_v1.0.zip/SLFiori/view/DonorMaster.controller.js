sap.ui.controller("SLFiori.view.DonorMaster", {

	onInit: function() {
		this.router = sap.ui.core.UIComponent.getRouterFor(this);
		this.router.attachRoutePatternMatched(this._handleRouteMatched, this);

		this.NewEntry = {
			FormMode: "Add",
			CardCode: "",
			U_SFDC: "",
			CardName: "",
			U_SubCd: "",
			E_Mail: "",
			Phone1: "",
			Organisation: "",
			GroupCode: "",
			GroupName: "",
			U_RCAct: "",
			FTaxID: "",
			U_LTOffNo: "",
			U_VATCode: "",
			U_UKStart: "",
			U_UKEnd: "",
			Currency: "##",
			Valid: "",
			U_BPUpded: "N",

			ContactPersons: [

		                               ],

			Address: [

		                               ],
			Countries: []
		};

		this.list = {
			FormMode: "Update",
			CardCode: "",
			U_SFDC: "",
			CardName: "",
			U_SubCd: "",
			E_Mail: "",
			Phone1: "",
			Organisation: "",
			GroupCode: "",
			GroupName: "",
			U_RCAct: "",
			FTaxID: "",
			U_LTOffNo: "",
			U_VATCode: "",
			U_UKStart: "",
			U_UKEnd: "",
			Currency: "##",
			Valid: "",
            U_BPUpded: "N",
			ContactPersons: [

		                               ],

			Address: [

		                               ],
			Countries: []
			//{key: "Yes",value: "Yes"}, {key: "No", value: "No"}
		};

		this.oModel = new sap.ui.model.json.JSONModel(this.list);
		this.getView().setModel(this.oModel);
	},

	handleSaveDonor: function() {

		var oModelData = this.oModel.getData();

		var jData = JSON.stringify({
			CardCode: oModelData.CardCode,
			CardName: oModelData.CardName,
			EmailAddress: oModelData.E_Mail,
			Phone1: oModelData.Phone1,
			CardForeignName: oModelData.Organisation,
			FederalTaxID: oModelData.FTaxID,
			GroupCode:oModelData.GroupCode,
			Currency: "##",
			CardType: "C",
			Valid: "Y",
			ValidFrom: "20170101",
			//U_BPUpded : "N",
			"ContactEmployees": oModelData.ContactPersons,
			"BPAddresses": oModelData.Address
		});

		if (oModelData.FormMode !== "Add") {
			$.ajax({
				//url: "https://10.0.1.189:50000/b1s/v1/BusinessPartners('"+oModelData.CardCode+"')",
				url: "/b1s/v1/BusinessPartners('" + oModelData.CardCode + "')",
				xhrFields: {
					withCredentials: true
				},
				data: jData,
				type: "PATCH",
				dataType: "json",
				success: function(json) {
					sap.m.MessageToast.show("Business Partner Updated Sucessfully");

					// 	var TargetDBSession = "";
					// 	//Login to SO DataBase
					// 	var jDataLogin = JSON.stringify({
					// 		UserName: "manager",
					// 		Password: "A123",
					// 		CompanyDB: "UK"
					// 	});
					// 	$.ajax({
					// 		url: "/b1s/v1/Login",
					// 		xhrFields: {
					// 			withCredentials: true
					// 		},
					// 		data: jDataLogin,
					// 		type: "POST",
					// 		dataType: "json",
					// 		success: function(json) {
					// 			//console.log("Logged in Succesfully-UK");
					// 			sap.m.MessageToast.show("Logged in Succesfully-UK");
					// 			TargetDBSession = json.SessionId;

					// 			//BP Master Updating in Subsidary DB
					// 			$.ajax({
					// 				//url: "https://10.0.1.189:50000/b1s/v1/BusinessPartners('"+oModelData.CardCode+"')",
					// 				url: "/b1s/v1/BusinessPartners('" + oModelData.CardCode + "')",
					// 				xhrFields: {
					// 					withCredentials: true
					// 				},
					// 				beforeSend: function(xhr) {
					// 					xhr.setRequestHeader("B1SESSION", TargetDBSession);
					// 				},

					// 				data: jData,
					// 				type: "PATCH",
					// 				dataType: "json",
					// 				success: function(json) {
					// 					sap.m.MessageToast.show("Business Partner Updated Sucessfully-Subsidary");
					// 					//console.log("Business Partner Updated Sucessfully");
					// 				},
					// 				error: function(xhr, status, errorThrown) {
					// 					//sap.m.MessageToast.show("Error: " + errorThrown);
					// 					sap.m.MessageToast.show("Error: " + xhr.responseJSON.error.message.value);
					// 				},
					// 				complete: function(xhr, status) {}
					// 			});
					// 			//BP Master Subsidary Posting 

					// 			//Logout from BP Master Subsidary	      
					// 			//var jDataLogout =  JSON.stringify({UserName: "manager", Password: "A123", CompanyDB: "UK"});	
					// 			//         $.ajax({
					// 			//      url: "/b1s/v1/Logout",
					// 			//             xhrFields: {
					// 			//                 withCredentials: true
					// 			//             },
					// 			//             beforeSend: function(xhr) {
					// 			//         		    xhr.setRequestHeader("B1SESSION",TargetDBSession);
					// 			//         		},
					// 			//      //data: jDataLogin,
					// 			//      type: "POST",
					// 			//      dataType : "json",
					// 			//      success: function( json ) {
					// 			//             //console.log("Logged out Succesfully");
					// 			//             sap.m.MessageToast.show("Logged out Succesfully");
					// 			//      },
					// 			//      error: function( xhr, status, errorThrown ) {
					// 			//   sap.m.MessageToast.show("Error: " + xhr.responseJSON.error.message.value);
					// 			//      },
					// 			//      complete: function( xhr, status ) {
					// 			//      }
					// 			//         });
					// 			//LogOut from BP Master Subsidary// 

					// 		},
					// 		error: function(xhr, status, errorThrown) {
					// 			sap.m.MessageToast.show("Error: " + xhr.responseJSON.error.message.value);
					// 		},
					// 		complete: function(xhr, status) {}
					// 	});
					// 	//Login to SO DataBase//

				},
				error: function(xhr, status, errorThrown) {
					//sap.m.MessageToast.show("Error: " + errorThrown);
					sap.m.MessageToast.show("Error: " + xhr.responseJSON.error.message.value);
				},
				complete: function(xhr, status) {}
			});
			//Updating of BP's Processed//

		} else {
			$.ajax({
				//url: "https://10.0.1.189:50000/b1s/v1/BusinessPartners",
				url: "/b1s/v1/BusinessPartners",
				xhrFields: {
					withCredentials: true
				},
				data: jData,
				type: "POST",
				dataType: "json",
				success: function(json) {
					sap.m.MessageToast.show("Business Partner Added Sucessfully");
				},
				error: function(xhr, status, errorThrown) {
					sap.m.MessageToast.show("Error: " + errorThrown);
				},
				complete: function(xhr, status) {}
			});
		}
	},

	handleAddNewDonor: function() {
		this.oModel = new sap.ui.model.json.JSONModel(this.NewEntry);
		this.getView().setModel(this.oModel);
	},

	_handleRouteMatched: function(data) {
		this.BPCode = data.mParameters.arguments.Key;
		//this.SessionID = data.mParameters.arguments.Session;

		if (this.BPCode === "0") {
			this.oModel = new sap.ui.model.json.JSONModel(this.NewEntry);
			this.getView().setModel(this.oModel);
		} else {
			var oParameter = data.getParameter("name");
			if (oParameter !== "DonorMaster") {
				return;
			}
			var oModelData = this.oModel.getData();
			var that = this;
			$.ajax({
				//url: "/b1s/v1/BusinessPartners('" + this.BPCode + "')",
				url: "OData/masters/donormaster/donorlist_header.xsodata/CardCode?$filter=CardCode eq '" + this.BPCode + "'",
				xhrFields: {
					withCredentials: true
				},
				async: false,
				type: "GET",
				dataType: "json",
				success: function(oData, oResponse) {

					that.oModel.setProperty("/FormMode", "Update");
					that.oModel.setProperty("/CardCode", oData.d.results[0].CardCode);
					//that.oModel.setProperty("/U_SFDC", oData.U_SFDC);
					that.oModel.setProperty("/CardName", oData.d.results[0].CardName);
					that.oModel.setProperty("/E_Mail", oData.d.results[0].E_Mail);
					that.oModel.setProperty("/Phone1", oData.d.results[0].Cellular);
					that.oModel.setProperty("/Organisation", oData.d.results[0].CardFName);
					that.oModel.setProperty("/GroupCode", oData.d.results[0].GroupCode);
					//that.oModel.setProperty("/GCrDate", oData.d.results[0].U_GCrDate);
					that.oModel.setProperty("/FTaxID", oData.d.results[0].LicTradNum);
					//that.oModel.setProperty("/U_LTOffNo", oData.d.results[0].U_LTOffNo);
					//that.oModel.setProperty("/U_VATCode", oData.d.results[0].U_VATCode);
					//that.oModel.setProperty("/U_UKStart", oData.d.results[0].U_UKStart);
					//that.oModel.setProperty("/U_UKEnd", oData.d.results[0].U_UKEnd);
					that.oModel.setProperty("/Currency", oData.d.results[0].Currency);

					//that.oModel.getData().Address = oData.BPAddresses;
					//that.oModel.getData().ContactPersons = oData.ContactEmployees;

					that.oModel.refresh();
				},
				error: function(oError) {
					sap.m.MessageToast.show("Error: " + oError);
				}
			});
                
                var oModelData = this.oModel.getData();
				$.ajax({
					//url: "/b1s/v1/BusinessPartners('" + this.BPCode + "')", + this.GroupCode + 
					
				// 	url: "/b1s/v1/BusinessPartnerGroups(" + oModelData.GroupCode + ")?$select=Name",
				// 	 xhrFields: {
			 //           withCredentials: true
			 //       },
			 //       async: false,
				// 	type: "GET",
				// 	dataType : "json",
				// 	success: function( oData, oResponse) {
				// 	that.oModel.setProperty("/GroupName", oData.Name);
			 //       that.oModel.refresh();
				// 	},
				url: "OData/masters/donormaster/donorlist_cntpersons.xsodata/CardCode?$filter=CardCode eq '" + this.BPCode + "'",
				xhrFields: {
					withCredentials: true
				},
				async: false,
				type: "GET",
				dataType: "json",
				success: function(oData, oResponse) {
					var oResults = oData.d.results;
					for (var i = 0; i < oResults.length; i++) {
						delete oResults[i].__metadata;
						delete oResults[i].COL;
					}
					that.oModel.getData().ContactPersons = oResults;
					that.oModel.refresh();
				},
					error: function(oError) {
						sap.m.MessageToast.show("Error: " + oError);
					}
				});
				
			var oModelData = this.oModel.getData();
				$.ajax({
				url: "OData/masters/donormaster/donorlist_address.xsodata/AddressName?$filter=BPCode eq '" + this.BPCode + "'",
				xhrFields: {
					withCredentials: true
				},
				async: false,
				type: "GET",
				dataType: "json",
				success: function(oData, oResponse) {
					var oResults = oData.d.results;
					for (var i = 0; i < oResults.length; i++) {
						delete oResults[i].__metadata;
						delete oResults[i].COL;
					}
					that.oModel.getData().Address = oResults;
					that.oModel.refresh();
				},
					error: function(oError) {
						sap.m.MessageToast.show("Error: " + oError);
					}
				});
		}
	},

	onAfterRendering: function() {
		//this.byId("idProductsTable").setWidths(["30%", "70%"]);
	},

	onBack: function() {
		var that = this;
		// 		that.router.navTo("Dashboard", {
		// 			Session: this.SessionID
		// 		});
		that.router.navTo("Dashboard");
	},

	handleAddCntPerRow: function() {
		var oModel = this.oModel;
		var oModelData = oModel.getData();
		var oNewRow = {
			Name: "",
			FirstName: "",
			MiddleName: "",
			LastName: "",
			MobilePhone: "",
			E_Mail: "",
			Remarks1: ""
		};
		var iErrorCount = 0;
		for (var i = 0; i <= oModelData.ContactPersons.length - 1; i++) {
			if (oModelData.ContactPersons[i].Name == "") {
				sap.m.MessageToast.show("Please enter Contact Person ID");
				iErrorCount = iErrorCount + 1;
				break;
			}
		}
		if (iErrorCount === 0) {
			oModelData.ContactPersons.push(oNewRow);
			oModel.refresh();
		}
	},

	handleAddAddressRow: function() {
		var oModel = this.oModel;
		var oModelData = oModel.getData();
		var oNewRow = {
			AddressName: "",
			StreetNo: "",
			Street: "",
			Block: "",
			City: "",
			State: "",
			County: "",
			ZipCode: "",
			Country: ""
		};
		var iErrorCount = 0;
		for (var i = 0; i <= oModelData.Address.length - 1; i++) {
			if (oModelData.Address[i].AddressName == "") {
				sap.m.MessageToast.show("Please enter Address ID");
				iErrorCount = iErrorCount + 1;
				break;
			}
		}
		if (iErrorCount === 0) {
			oModelData.Address.push(oNewRow);
			oModel.refresh();
		}
	},

	handleDonorList: function(oEvent) {
		var that = this;
		if (!this.oDonorMasterDialog) {
			this.oDonorMasterDialog = sap.ui.xmlfragment("SLFiori.fragments.DonorMaster", this);
		}
		sap.ui.getCore().byId("DonorListTable").removeSelections();
		this.oDonorMasterDialog.setModel(this.oModel);
		$.ajax({
			//url: "https://10.0.1.189:50000/b1s/v1/BusinessPartners?$select=CardCode,CardName,ContactPerson,Cellular,EmailAddress&$filter=Valid eq 'Y' and Frozen eq 'N' and CardType eq 'C' &$top=1000 &$orderby=CardName",
			url: "/b1s/v1/BusinessPartners?$select=CardCode,CardName,ContactPerson,Cellular,EmailAddress&$filter=Valid eq 'Y' and Frozen eq 'N' and CardType eq 'C' &$top=1000 &$orderby=CardName",
			xhrFields: {
				withCredentials: true
			},
			async: false,
			type: "GET",
			dataType: "json",
			success: function(oData, oResponse) {
				that.oModel.getData().DonorList = oData.d.results; //oData.value;
				that.oModel.refresh();
				that.oDonorMasterDialog.open();
			},
			error: function(oError) {
				sap.m.MessageToast.show("Error: " + oError);
			}
		});
	},

	handleCustOk: function(oEvent) {
		var oDonorListTable = sap.ui.getCore().byId("DonorListTable");
		var oSelectedDonor = oDonorListTable.getSelectedItem();
		if (oSelectedDonor) {
			var oSelctedCustContext = oSelectedDonor.getBindingContext();
			var path = oSelctedCustContext.sPath;
			var Donor = this.oModel.getProperty(path);
			this.oModel.setProperty("/DnrCod", Donor.CardCode);
			this.oModel.setProperty("/DnrNam", Donor.CardName);
			//this.oModel.setProperty("/DonorCnt", Donor.CntctPrsn);
			//this.oModel.setProperty("/TelNo", Donor.Cellular);

			this.oModel.refresh();
			sap.ui.getCore().byId("DonorListTable").removeSelections();
			this.oDonorMasterDialog.close();
		} else {
			sap.m.MessageToast.show("Please select Donor");
		}
	},

	handleCustClose: function() {
		sap.ui.getCore().byId("DonorListTable").removeSelections();
		this.oDonorMasterDialog.close();
	},

	handleGroupList: function(oEvent) {
		var that = this;
		if (!this.oGroupDialog) {
			this.oGroupDialog = sap.ui.xmlfragment("SLFiori.fragments.GroupMasterV2", this);
		}
		sap.ui.getCore().byId("GroupListTable").removeSelections();
		this.oGroupDialog.setModel(this.oModel);
		$.ajax({
			//url: "https://10.0.1.189:50000/b1s/v1/BusinessPartnerGroups?$select=Code,Name",
			url: "/b1s/v1/BusinessPartnerGroups?$select=Code,Name",
			xhrFields: {
				withCredentials: true
			},
			async: false,
			type: "GET",
			dataType: "json",
			success: function(oData, oResponse) {
				that.oModel.getData().GroupMaster = oData.value;
				that.oModel.refresh();
				that.oGroupDialog.open();
			},
			error: function(oError) {
				sap.m.MessageToast.show("Error: " + oError);
			}
		});
	},

	handleGroupOk: function(oEvent) {
		var oGroupListTable = sap.ui.getCore().byId("GroupListTable");
		var oSelectedGroup = oGroupListTable.getSelectedItem();
		if (oSelectedGroup) {
			var oSelctedCustContext = oSelectedGroup.getBindingContext();
			var path = oSelctedCustContext.sPath;
			var Donor = this.oModel.getProperty(path);
			this.oModel.setProperty("/GroupName", Donor.Name);
			this.oModel.setProperty("/GroupCode", Donor.Code);
			//this.oModel.setProperty("/TelNo", Donor.Cellular);

			this.oModel.refresh();
			sap.ui.getCore().byId("GroupListTable").removeSelections();
			this.oGroupDialog.close();
		} else {
			sap.m.MessageToast.show("Please select Group");
		}
	},

	handleGroupClose: function() {
		sap.ui.getCore().byId("GroupListTable").removeSelections();
		this.oGroupDialog.close();
	},

	handleCountryList: function(oEvent) {
		var that = this;
		if (!this.oCountryDialog) {
			this.oCountryDialog = sap.ui.xmlfragment("SLFiori.fragments.Countries", this);
		}
		this.oCountries = "";
		var oCountriesBindingContextPath = oEvent.getSource().getBindingContext().sPath.split("/");
		var aCountriesSelectedPathLength = oCountriesBindingContextPath.length;
		var oCountriesRowId = aCountriesSelectedPathLength - 1;
		this.oCountriesRowId = oCountriesBindingContextPath[oCountriesRowId];

		sap.ui.getCore().byId("CountryListTable").removeSelections();
		this.oCountryDialog.setModel(this.oModel);
		$.ajax({
			//url: "https://10.0.1.189:50000/b1s/v1/Countries?$select=Code,Name",
			url: "/b1s/v1/Countries?$select=Code,Name",
			xhrFields: {
				withCredentials: true
			},
			async: false,
			type: "GET",
			dataType: "json",
			success: function(oData, oResponse) {
				var aItemsData = oData.value;
				for (var m = 0; m < aItemsData.length; m++) {
					aItemsData[m].Amount = "0";
				}
				that.oModel.getData().Countries = oData.Value;
				that.oModel.refresh();
				that.oCountryDialog.open();
			},
			error: function(oError) {
				sap.m.MessageToast.show("Error: " + oError);
			}
		});
	},

	handleCountryOk: function(oEvent) {
		var oCountryListTable = sap.ui.getCore().byId("CountryListTable");
		var oSelectedRevType = oCountryListTable.getSelectedItem();
		if (oSelectedRevType) {
			var oSelctedCustContext = oSelectedRevType.getBindingContext();
			var path = oSelctedCustContext.sPath;
			var RevType = this.oModel.getProperty(path);
			//this.oModel.setProperty("/TaxCode", Tax.Code);
			this.oModel.setProperty("/ContactPersons/" + this.oRevTypeRowId + "/U_RevenTyp", RevType.Name);
			this.oModel.refresh();
			sap.ui.getCore().byId("CountryListTable").removeSelections();
			this.oRevTypeDialog.close();
		} else {
			sap.m.MessageToast.show("Please select Country");
		}

	},

	handleCountryClose: function(oEvent) {
		this.oCountryDialog.close();
	},
	
	onGroupSearch : function (oEvt) {
            var list = sap.ui.getCore().byId("GroupListTable");//this.getView().byId("idList");
			var oBinding = list.getBinding("items");
			// add filter for search
			var aFilters = [];
			var sQuery = oEvt.getSource().getValue();
			if (sQuery && sQuery.length > 0) {
				var filter = new sap.ui.model.Filter("Name", sap.ui.model.FilterOperator.Contains, sQuery);
				aFilters.push(filter);
			}
			oBinding.filter(aFilters);
	}

});