sap.ui.controller("SLFiori.view.Login", {

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf empcreate.create
*/
	onInit: function() {
			//this.oRouter = sap.ui.core.routing.Router.getRouter("router");  
				this.router = sap.ui.core.UIComponent.getRouterFor(this);
		//this.router.attachRoutePatternMatched(this.handleRouteMatched, this);
		this._url = this.getOwnerComponent().getMetadata().getConfig().serviceConfig.serviceUrl;
	},
/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf empcreate.create
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf empcreate.create
*/
	onAfterRendering: function() {
		//this.resetEmployeeObject();
	},
	
    handleLogin : function(oEvent){
	    var that = this;
	    var UName = this.byId("UName").getValue();
	    var Password = this.byId("Passwd").getValue();
		var jData =  JSON.stringify({UserName : UName, Password: Password, CompanyDB: "CMD"});
		
	    //var jData =  JSON.stringify({UserName: "manager", Password: "manager", CompanyDB: "SBODEMOIN"});	
	 $.ajax({
        		type: "POST",
        		url: "/sap/sbo/platform/login",
        		headers: {
        			"Authorization": "Basic " + btoa("SYSTEM" + ":" + "Ashoka@123")
        		},
        		beforeSend: function(xhr) {
        			xhr.setRequestHeader("X-CSRF-Token", "Fetch");
        		},
        		data: {
        			"company": "CMD",
        			"username": "manager",
        			"password": "A123",
        			"language": "en-US"
        		},
        		error: function(xhr, status, error) 
        		{
        		    
        			  var data = JSON.parse(xhr.responseText);
        		      window.alert("Login failed: " +data['msg']);
        		},
        		success: function(json, textStatus, XMLHttpRequest) {
        			//$("#wait").css("display", "none");
        			console.log("Success");
        			//login_service(user.value, pass.value);
        		}
        	});
        	
	$.ajax({
		url: "/b1s/v1/Login",
		
		//url: "https://10.0.1.189:50000/b1s/v1/Login",
		//url: this._url,
		//url: "sap/sbo/platform/login",
        xhrFields: {
            withCredentials: true
        },
		data: jData,
		type: "POST",
		dataType : "json",
		success: function( json ) {
            //that.router.navTo("Dashboard",{Session:json.SessionId});
            that.router.navTo("Dashboard");
		},
		error: function( oError ) {
			sap.m.MessageToast.show("Error: " + oError.responseJSON.error.message.value);
			//alert("Error: " + errorThrown);
			//connected = false;
		},
		complete: function( xhr, status ) {
		}
	});
},

	handleAdd : function(oEvent){
	    var GC = document.getElementById("idMain1--GCode-inner");
		var jData =  JSON.stringify({U_IKGRCD : GC.value});	
	$.ajax({
		url: "https://172.31.28.160:50000/b1s/v1/IKGRANTUDO",
        xhrFields: {
          withCredentials: true
        },
		data: jData,
		type: "POST",
		dataType : "json",
		success: function( json ) {
			alert("Posting Success")
		},
		error: function( xhr, status, errorThrown ) {
		        alert(errorThrown);
		},
		complete: function( xhr, status ) {
		}
	});
	}


});