sap.ui.controller("SLFiori.view.GrantAllocation", {

	onInit: function() {
		this.router = sap.ui.core.UIComponent.getRouterFor(this);
		this.router.attachRoutePatternMatched(this._handleRouteMatched, this);
		this.GrantEntry = "";
		//this.getRouter().attachRoutePatternMatched(this.onRouteMatched, this);

		this.NewEntry = {
			FormMode: "Add",
			GrantEnt:"",
			DocNum: "",
			GCrDate: "",
			Status: "",
			GName: "",
			GCode: "",
			GrantCur: "",
			GrRes: "",
			GrFinMan: "",
			GMan: "",
			GCNum: "",
			GCAmnt: "",
			FRType: "",
			FrAmt: "",
			FrAmUSD: "",
			DnrNam: "",
			DnrCod: "",
			DSFDCId: "",
			GCType: "",
			GCFrom: "",
			GCTo: "",
			GCAmt: "",
			Rmks: "",
			Athmnt: "",

			SODBNAME: "",

			GrantList: [

		                               ],
			DonorList: [

                                       ],
			CostCentersList: [

                                       ],
			Dim2List: [

                                       ],
			Dim3List: [

                                       ],
			Dim4List: [

                                       ],
			Dim5List: [

                                       ],

			InPayDetails: [
				{
					LineId: "1",
					U_PaySub: "",
					U_PayNo: "",
					U_PayDate: "",
					U_PayAmt: "",
					U_GrCur: "",
					U_PayUSD: ""
				}
                      ],

			FreezingDetails: [

                       ],

			ComboList: [{
				key: "R",
				value: "Released"
			}, {
				key: "O",
				value: "Open"
			}, {
				key: "C",
				value: "Closed"
			}],

			ComboYesNo: [{
				key: "Yes",
				value: "Yes"
			}, {
				key: "No",
				value: "No"
			}],

			ComboType: [{
				key: "P",
				value: "Pledged"
			}, {
				key: "U",
				value: "UnPledged"
			}],

			ComboRes: [{
				key: "U",
				value: "UnRestricted"
			}, {
				key: "R",
				value: "Restricted"
			}],

			ComboFrType: [{
				key: "PR",
				value: "Pre-Cash"
			}, {
				key: "IP",
				value: "Incoming Payments"
			}]

		};

		this.list = {
			FormMode: "Update",
			GrantEnt:"",
			DocNum: "",
			GCrDate: "",
			Status: "",
			GName: "",
			GCode: "",
			GrantCur: "",
			GrRes: "",
			GrFinMan: "",
			GMan: "",
			GCNum: "",
			GCAmnt: "",
			FRType: "",
			FrAmt: "",
			FrAmUSD: "",
			DnrNam: "",
			DnrCod: "",
			DSFDCId: "",
			GCType: "",
			GCFrom: "",
			GCTo: "",
			GCAmt: "",
			Rmks: "",
			Athmnt: "",

			SODBNAME: "",

			GrantList: [

		                               ],
			DonorList: [

                                       ],
			CostCentersList: [

                                       ],
			Dim2List: [

                                       ],
			Dim3List: [

                                       ],
			Dim4List: [

                                       ],
			Dim5List: [

                                       ],

			InPayDetails: [
				{
					LineId: "1",
					U_PaySub: "",
					U_PayNo: "",
					U_PayDate: "",
					U_PayAmt: "",
					U_GrCur: "",
					U_PayUSD: ""
				}
                      ],

			FreezingDetails: [

                       ],

			ComboList: [{
				key: "R",
				value: "Released"
			}, {
				key: "O",
				value: "Open"
			}, {
				key: "C",
				value: "Closed"
			}],

			ComboYesNo: [{
				key: "Yes",
				value: "Yes"
			}, {
				key: "No",
				value: "No"
			}],

			ComboType: [{
				key: "P",
				value: "Pledged"
			}, {
				key: "U",
				value: "UnPledged"
			}],

			ComboRes: [{
				key: "U",
				value: "UnRestricted"
			}, {
				key: "R",
				value: "Restricted"
			}],

			ComboFrType: [{
				key: "PR",
				value: "Pre-Cash"
			}, {
				key: "IP",
				value: "Incoming Payments"
			}]

		};

		this.oModel = new sap.ui.model.json.JSONModel(this.list);
		this.getView().setModel(this.oModel);
	},

	handleSaveFreezing: function(oEvent) {

		/*var jData =  JSON.stringify({CardCode:"C20000",
		                            DocumentLines:[{ItemCode:"A00001",TaxCode:"VAT@4",Quantity:"110","UnitPrice":"20"}]
		});*/
		var oModelData = this.oModel.getData();

		var that = this;

		var jData = JSON.stringify({
			U_SFDCOppN: oModelData.SFDCOppN,
			U_GCrDate: oModelData.GCrDate,
			U_Status: oModelData.Status,
			U_DnrCod: oModelData.DnrCod,
			U_DnrNam: oModelData.DnrNam,
			U_DSFDCId: oModelData.DSFDCId,
			U_GCType: oModelData.GCType,

			//U_CommGrnt: oModelData.CommGrnt,

			U_GCFrom: oModelData.GCFrom,
			U_GCTo: oModelData.GCTo,
			U_GCAmt: oModelData.GCAmt,
			U_GCode: oModelData.GCode,
			U_GName: oModelData.GName,
			U_GrantCur: oModelData.GrantCur,
			U_GrRes: oModelData.GrRes,
			U_GrFinMan: oModelData.GrFinMan,
			U_GMan: oModelData.GMan,
			U_Rmks: oModelData.Rmks,
			U_Athmnt: oModelData.Athmnt,

			//			U_GDate: oModelData.GDate,
			U_GSCCov: oModelData.GSCCov,
			U_GSCCovPr: oModelData.GSCCovPr,
			//U_GRelsSt: oModelData.GRelsSt,

			//"IK_NCT1Collection":[{U_RevenSub:oModelData.GrantRevenueDetails.RevenSub}]
			"IK_NCT1Collection": oModelData.GrantRevenueDetails,
			//"IK_NCT2Collection": oModelData.GrantPaymentSchedule,
			"IK_NCT3Collection": oModelData.GrantRevenueAllocation
			//"IK_NCT4Collection":oModelData.GrantInitiative,
			//"IK_NCT5Collection":oModelData.GrantReporting
		});
		//var CardCode = this.byId("sId")

		if (oModelData.FormMode !== "Add") {
			//sap.m.MessageToast.show("FormMode-Update");
			//this.GrantEntry=data.mParameters.arguments.Key;
			$.ajax({
				url: "/b1s/v1/IK_GNCT(" + oModelData.GrantEntryNo + ")",
				xhrFields: {
					withCredentials: true
				},
				data: jData,
				type: "PATCH",
				dataType: "json",
				success: function(json) {
					sap.m.MessageToast.show("Grant Contract Updated Sucessfully");
				},
				error: function(xhr, status, errorThrown) {
					sap.m.MessageToast.show("Error: " + errorThrown);
				},
				complete: function(xhr, status) {}
			});
		} else {
			//sap.m.MessageToast.show("FormMode-Add");
			$.ajax({

				url: "/b1s/v1/IK_GNCT",
				xhrFields: {
					withCredentials: true
				},
				data: jData,
				type: "POST",
				dataType: "json",
				success: function(json) {
					sap.m.MessageToast.show("Grant Contract Posted Sucessfully");
				},
				error: function(xhr, status, errorThrown) {
					sap.m.MessageToast.show("Error: " + errorThrown);
				},
				complete: function(xhr, status) {}
			});
		}

	},

	/*handleAddEntry: function() {
		var oPanel = this.getView().byId("_HBox");
		oPanel.setBusy(true);

		this.oModel = new sap.ui.model.json.JSONModel(this.NewEntry);
		this.getView().setModel(this.oModel);

		oPanel.setBusy(false);
	},*/

	_handleRouteMatched: function(data) {
		this.GrantEntry = data.mParameters.arguments.Key;
		var oParameter = data.getParameter("name");
		if (oParameter !== "GrantContract") {
			return;
		}
		var oModelData = this.oModel.getData();
		var that = this;
		$.ajax({
			url: "OData/GrantContract_Header.xsodata/GrantContract?$filter=DocEntry eq '" +
				this.GrantEntry + "'",
			xhrFields: {
				withCredentials: true
			},
			async: false,
			type: "GET",
			dataType: "json",
			success: function(oData, oResponse) {
				var oResults = oData.d.results;
				for (var i = 0; i < oResults.length; i++) {
					delete oResults[i].__metadata;
				}
				//that.oModel.getData().GrantRevenueDetails = oResults;
				that.oModel.setProperty("/GrantEntryNo", oData.d.results[0].DocEntry);
				that.oModel.setProperty("/GCDocNum", oData.d.results[0].DocNum);
				that.oModel.setProperty("/GCode", oData.d.results[0].GCode);
				that.oModel.setProperty("/GName", oData.d.results[0].U_GName);
				that.oModel.setProperty("/DnrCod", oData.d.results[0].U_DnrCod);
				that.oModel.setProperty("/DnrNam", oData.d.results[0].U_DnrNam);
				that.oModel.setProperty("/DSFDCId", oData.d.results[0].U_DSFDCId);
				that.oModel.setProperty("/CommGrnt", oData.d.results[0].U_CommGrnt);
				that.oModel.setProperty("/GCrDate", oData.d.results[0].U_GCrDate);
				//that.oModel.setProperty("/GCrDate", "2017-04-25");
				that.oModel.setProperty("/Status", oData.d.results[0].U_Status);
				that.oModel.setProperty("/SFDCOppN", oData.d.results[0].U_SFDCOppN);
				that.oModel.setProperty("/GrantCur", oData.d.results[0].U_GrantCur);
				that.oModel.setProperty("/GCAmt", oData.d.results[0].U_GCAmt);
				that.oModel.setProperty("/GDate", oData.d.results[0].U_GDate);
				that.oModel.setProperty("/GSCCov", oData.d.results[0].U_GSCCov);
				that.oModel.setProperty("/GSCCovPr", oData.d.results[0].U_GSCCovPr);
				that.oModel.setProperty("/GRelsSt", oData.d.results[0].U_GRelsSt);
				that.oModel.setProperty("/GCFrom", oData.d.results[0].U_GCFrom);
				//that.oModel.setProperty("/GCFrom", "2017-04-25");
				that.oModel.setProperty("/GCTo", oData.d.results[0].U_GCTo);
				that.oModel.setProperty("/GrFinMan", oData.d.results[0].U_GrFinMan);
				that.oModel.setProperty("/GMan", oData.d.results[0].U_GMan);
				that.oModel.setProperty("/Athmnt", oData.d.results[0].U_Athmnt);
				that.oModel.setProperty("/Rmks", oData.d.results[0].U_Rmks);
				that.oModel.setProperty("/GCType", oData.d.results[0].U_GCType);
				that.oModel.setProperty("/GrRes", oData.d.results[0].U_GrRes);

				that.oModel.refresh();
			},
			error: function(oError) {
				sap.m.MessageToast.show("Error: " + oError);
			}
		});

		$.ajax({
			url: "OData/GrantContract_RevenueDetails.xsodata/GrantContract?$filter=DocEntry eq '" +
				this.GrantEntry + "'&$orderby=LineId asc",
			xhrFields: {
				withCredentials: true
			},
			async: false,
			type: "GET",
			dataType: "json",
			success: function(oData, oResponse) {
				var oResults = oData.d.results;
				for (var i = 0; i < oResults.length; i++) {
					delete oResults[i].__metadata;
				}
				that.oModel.getData().GrantRevenueDetails = oResults;
				that.oModel.refresh();
			},
			error: function(oError) {
				sap.m.MessageToast.show("Error: " + oError);
			}
		});

		$.ajax({
			url: "OData/GrantContract_RevenueAllocation.xsodata/GrantContract?$filter=DocEntry eq '" +
				this.GrantEntry + "'&$orderby=LineId asc",
			xhrFields: {
				withCredentials: true
			},
			async: false,
			type: "GET",
			dataType: "json",
			success: function(oData, oResponse) {
				var oResults = oData.d.results;
				for (var i = 0; i < oResults.length; i++) {
					delete oResults[i].__metadata;
				}
				that.oModel.getData().GrantRevenueAllocation = oResults;
				that.oModel.refresh();
			},
			error: function(oError) {
				sap.m.MessageToast.show("Error: " + oError);
			}
		});

		// 		$.ajax({
		// 			url: "OData/GrantContract_PaymentSchedule.xsodata/GrantContract?$filter=DocEntry eq '" +
		// 				this.GrantEntry + "'",
		// 			xhrFields: {
		// 				withCredentials: true
		// 			},
		// 			async: false,
		// 			type: "GET",
		// 			dataType: "json",
		// 			success: function(oData, oResponse) {
		// 				var oResults = oData.d.results;
		// 				for (var i = 0; i < oResults.length; i++) {
		// 					delete oResults[i].__metadata;
		// 				}
		// 				that.oModel.getData().GrantPaymentSchedule = oResults;
		// 				that.oModel.refresh();
		// 			},
		// 			error: function(oError) {
		// 				sap.m.MessageToast.show("Error: " + oError);
		// 			}
		// 		});
	},

	onAfterRendering: function() {
		//this.byId("idProductsTable").setWidths(["30%", "70%"]);
	},

	onBack: function() {
		var that = this;
		that.router.navTo("Dashboard");
	},

	handleAddRow: function() {

		/*var jData =  JSON.stringify({CardCode:"C20000",
		                            DocumentLines:[{ItemCode:"A00001",TaxCode:"VAT@4",Quantity:"110","UnitPrice":"20"}]
		});*/
		var oModel = this.oModel;
		var oModelData = oModel.getData();
		var oNewRow = {
			LineId: oModelData.InPayDetails.length + 1,
			U_PaySub: "",
			U_PayNo: "",
			U_PayDate: "",
			U_PayAmt: "",
			U_GrCur: "",
			U_PayUSD: ""
		};
		var iErrorCount = 0;
		for (var i = 0; i <= oModelData.InPayDetails.length - 1; i++) {
			if (oModelData.InPayDetails[i].U_PaySub == "") {
				sap.m.MessageToast.show("Please enter Payment Subsidary value");
				iErrorCount = iErrorCount + 1;
				break;
			}
		}
		if (iErrorCount === 0) {
			oModelData.InPayDetails.push(oNewRow);
			oModel.refresh();
		}
	},

	handleAddFreezingRow: function() {
		var oModel = this.oModel;
		var oModelData = oModel.getData();
		var oNewRow = {
			LineId: oModelData.FreezingDetails.length + 1,
			U_FrzSub: "",
			U_FrSubNm:"",
			U_FrzLoc: "",
			U_FrLocNm:"",
			U_FrzPgm: "",
			U_FrPgmNm:"",
			U_FrzPrPgm: "",
			U_GrInit: "",
			U_GrIntNm:"",
			U_Actvty: "",
			U_Amnt: "",
			U_Manager: "",
			U_CF: ""
		};
		var iErrorCount = 0;
		for (var i = 0; i <= oModelData.FreezingDetails.length - 1; i++) {
			if (oModelData.FreezingDetails[i].U_FrzSub == "") {
				sap.m.MessageToast.show("Please enter Freezing Subsidary value");
				iErrorCount = iErrorCount + 1;
				break;
			}
		}
		if (iErrorCount === 0) {
			oModelData.FreezingDetails.push(oNewRow);
			oModel.refresh();
		}
	},

	handleAddRevenueAllocationRow: function() {

		var grantRevenueTable = this.byId("idGrantRevenueDetails");

		var aSelectedItems = grantRevenueTable.getSelectedItems();
		if (aSelectedItems.length === 0) {
			sap.m.MessageToast.show("Please select Grant Revenue Details Row");
		}
		if (aSelectedItems.length > 1) {
			sap.m.MessageToast.show("Please select only ONE Grant Revenue Details Row");
		} else {
			var oSelectedRowContext = grantRevenueTable.getSelectedItem().getBindingContextPath();
			var oSelectedRowData = this.oModel.getProperty(oSelectedRowContext);

			var oModel = this.oModel;
			var oModelData = oModel.getData();
			var oNewRow = {
				LineId: oModelData.GrantRevenueAllocation.length + 1,
				U_GRevLNo: oSelectedRowData.LineId,
				U_AllcSub: "",
				U_AllcLoc: "",
				U_Remarks: "",
				U_Amt: ""
			};
			var iErrorCount = 0;

			if (iErrorCount === 0) {
				oModelData.GrantRevenueAllocation.push(oNewRow);
				oModel.refresh();
			}
		}
	},

	/*handleAddInitRow: function() {

		var oModel = this.oModel;
		var oModelData = oModel.getData();
		var oNewRow = {
			LineId: oModelData.GrantInitiative.length + 1,
			U_GrInit: ""
		};
		var iErrorCount = 0;
		for (var i = 0; i <= oModelData.GrantInitiative.length - 1; i++) {
			if (oModelData.GrantInitiative[i].U_GrInit == "") {
				sap.m.MessageToast.show("Please enter Initiative value");
				iErrorCount = iErrorCount + 1;
				break;
			}
		}
		if (iErrorCount === 0) {
			oModelData.GrantInitiative.push(oNewRow);
			oModel.refresh();
		}

		//var CardCode = this.byId("sId")

	},*/

/*	handleAddRpDtRow: function() {

		var oModel = this.oModel;
		var oModelData = oModel.getData();
		var oNewRow = {
			LineId: oModelData.GrantReporting.length + 1,
			U_GrRpDt: ""
		};
		var iErrorCount = 0;
		for (var i = 0; i <= oModelData.GrantReporting.length - 1; i++) {
			if (oModelData.GrantReporting[i].U_GrRpDt == "") {
				sap.m.MessageToast.show("Please enter Reporting Date");
				iErrorCount = iErrorCount + 1;
				break;
			}
		}
		if (iErrorCount === 0) {
			oModelData.GrantReporting.push(oNewRow);
			oModel.refresh();
		}

		//var CardCode = this.byId("sId")

	},*/

	handleAmountLiveChange: function(oEvent) {
		var oAmtBindingContextPath = oEvent.getSource().getBindingContext().sPath;
		//var aTaxSelectedPathLength = oTaxBindingContextPath.length;
		//var oTaxRowId = aTaxSelectedPathLength - 1;
		//this.oTaxRowId = oTaxBindingContextPath[oTaxRowId];
		this.oModel.setProperty(oAmtBindingContextPath + "/Amount", oEvent.oSource.getValue());
		var Amt = this.oModel.getProperty(oAmtBindingContextPath + "/Amount");

		//var Total = Qty*Price;
		this.oModel.refresh();
		//this.onPriceChange(oAmtBindingContextPath);
	},

	handleDonorList: function(oEvent) {
		var that = this;
		if (!this.oDonorMasterDialog) {
			this.oDonorMasterDialog = sap.ui.xmlfragment("SLFiori.fragments.DonorMasterV3", this);
		}
		sap.ui.getCore().byId("DonorListTable").removeSelections();
		this.oDonorMasterDialog.setModel(this.oModel);
		$.ajax({
			//url: "/b1s/v1/BusinessPartners?$select=CardCode,CardName,ContactPerson,Cellular,EmailAddress&$filter=Valid eq 'Y' and Frozen eq 'N' &$top=1000&$orderby=CardName",
			url: "/b1s/v1/BusinessPartners?$select=CardCode,CardName,ContactPerson,Cellular,EmailAddress&$filter=Valid eq 'Y' and Frozen eq 'N' &$top=1000&$orderby=CardName",
			xhrFields: {
				withCredentials: true
			},
			async: false,
			type: "GET",
			dataType: "json",
			success: function(oData, oResponse) {
				that.oModel.getData().DonorList = oData.value;
				that.oModel.refresh();
				that.oDonorMasterDialog.open();
			},
			error: function(oError) {
				sap.m.MessageToast.show("Error: " + oError);
			}
		});
	},

	handleCustOk: function(oEvent) {
		var oDonorListTable = sap.ui.getCore().byId("DonorListTable");
		var oSelectedDonor = oDonorListTable.getSelectedItem();
		if (oSelectedDonor) {
			var oSelctedCustContext = oSelectedDonor.getBindingContext();
			var path = oSelctedCustContext.sPath;
			var Donor = this.oModel.getProperty(path);
			this.oModel.setProperty("/DnrCod", Donor.CardCode);
			this.oModel.setProperty("/DnrNam", Donor.CardName);
			//this.oModel.setProperty("/DonorCnt", Donor.CntctPrsn);
			//this.oModel.setProperty("/TelNo", Donor.Cellular);

			this.oModel.refresh();
			sap.ui.getCore().byId("DonorListTable").removeSelections();
			this.oDonorMasterDialog.close();
		} else {
			sap.m.MessageToast.show("Please select Donor");
		}
	},

	handleCustClose: function() {
		sap.ui.getCore().byId("DonorListTable").removeSelections();
		this.oDonorMasterDialog.close();
	},

	handleCostCentersList: function(oEvent) {
		var that = this;
		if (!this.oCostCentersDialog) {
			this.oCostCentersDialog = sap.ui.xmlfragment("SLFiori.fragments.CostCentersV7", this);
		}
		sap.ui.getCore().byId("CostCentersListTable").removeSelections();
		this.oCostCentersDialog.setModel(this.oModel);
		$.ajax({
			//url: "https://172.31.28.160:50000/b1s/v1/BusinessPartners?$select=CardCode,CardName,CntctPrsn,Cellular?$filter=CardType eq 'C'",
			//url: "https://172.31.28.160:50000/b1s/v1/BusinessPartners?$select=CardCode,CardName,ContactPerson,Cellular",
			url: "OData/CostCenter.xsodata/CostCenter?$filter=DMCode eq '1'",
			xhrFields: {
				withCredentials: true
			},
			async: false,
			type: "GET",
			dataType: "json",
			success: function(oData, oResponse) {
				that.oModel.getData().CostCentersList = oData.d.results; //oData.value;
				that.oModel.refresh();
				that.oCostCentersDialog.open();
			},
			error: function(oError) {
				sap.m.MessageToast.show("Error: " + oError);
			}
		});
	},

	handleCostCentersOk: function(oEvent) {
		var oCostCentersListTable = sap.ui.getCore().byId("CostCentersListTable");
		var oSelectedCostCenter = oCostCentersListTable.getSelectedItem();
		if (oSelectedCostCenter) {
			var oSelctedCCContext = oSelectedCostCenter.getBindingContext();
			var path = oSelctedCCContext.sPath;
			var CC = this.oModel.getProperty(path);
			this.oModel.setProperty("/GCode", CC.CCCode);
			this.oModel.setProperty("/GName", CC.CCName);
			this.oModel.setProperty("/GrantCur", CC.U_GrCur);
			this.oModel.setProperty("/GrRes", CC.U_GrRes);
			// this.oModel.setProperty("/DonorCnt", Donor.CntctPrsn);
			// this.oModel.setProperty("/TelNo", Donor.Cellular);

			this.oModel.refresh();
			sap.ui.getCore().byId("CostCentersListTable").removeSelections();
			this.oCostCentersDialog.close();
		} else {
			sap.m.MessageToast.show("Please select Grant");
		}
	},

	handleCostCentersClose: function() {
		sap.ui.getCore().byId("CostCentersListTable").removeSelections();
		this.oCostCentersDialog.close();
	},

	handleDim2: function(oEvent) {
		var that = this;
		if (!this.oDim2Dialog) {
			this.oDim2Dialog = sap.ui.xmlfragment("SLFiori.fragments.Dim2", this);
		}
		this.oDim2 = "";
		var oDim2BindingContextPath = oEvent.getSource().getBindingContext().sPath.split("/");
		var aDim2SelectedPathLength = oDim2BindingContextPath.length;
		var oDim2RowId = aDim2SelectedPathLength - 1;
		this.oDim2RowId = oDim2BindingContextPath[oDim2RowId];

		sap.ui.getCore().byId("Dim2ListTable").removeSelections();
		this.oDim2Dialog.setModel(this.oModel);
		$.ajax({
			url: "OData/CostCenter.xsodata/CostCenter?$filter=DMCode eq '2'",
			xhrFields: {
				withCredentials: true
			},
			async: false,
			type: "GET",
			dataType: "json",
			success: function(oData, oResponse) {
				var aItemsData = oData.d.results; //oData.value;
				for (var m = 0; m < aItemsData.length; m++) {
					aItemsData[m].Amount = "0";
				}
				that.oModel.getData().Dim2List = oData.d.results;
				that.oModel.refresh();
				that.oDim2Dialog.open();
			},
			error: function(oError) {
				sap.m.MessageToast.show("Error: " + oError);
			}
		});
	},

	handleDim2Ok: function(oEvent) {
		var oDim2ListTable = sap.ui.getCore().byId("Dim2ListTable");
		var oSelectedDim2 = oDim2ListTable.getSelectedItem();
		//var oItems = this.oModel.getData().GrantRevenueDetails;

		if (oSelectedDim2) {
			var oSelctedCustContext = oSelectedDim2.getBindingContext();
			var path = oSelctedCustContext.sPath;
			var Dim2 = this.oModel.getProperty(path);
			//this.oModel.setProperty("/TaxCode", Tax.Code);
			//this.oModel.setProperty("/Dim2List/"+this.oDim2RowId + "/RevSub", Dim2.CCCode);
			this.oModel.setProperty("/FreezingDetails/" + this.oDim2RowId + "/U_FrzSub", Dim2.CCCode);
			this.oModel.setProperty("/FreezingDetails/" + this.oDim2RowId + "/U_FrSubNm", Dim2.CCName);
			this.oModel.refresh();
			sap.ui.getCore().byId("Dim2ListTable").removeSelections();
			this.oDim2Dialog.close();
		} else {
			sap.m.MessageToast.show("Please select Dimension");
		}

		//this.oModel.getData().GrantRevenueDetails = oItems;

	},

	handleDim2Close: function(oEvent) {
		this.oDim2Dialog.close();
	},

	/*handleAllcDim2: function(oEvent) {
		var that = this;
		if (!this.oDim2AllcDialog) {
			this.oDim2AllcDialog = sap.ui.xmlfragment("SLFiori.fragments.Dim2_AllocationV1", this);
		}
		this.oDim2 = "";
		var oDim2AllcBindingContextPath = oEvent.getSource().getBindingContext().sPath.split("/");
		var aDim2AllcSelectedPathLength = oDim2AllcBindingContextPath.length;
		var oDim2AllcRowId = aDim2AllcSelectedPathLength - 1;
		this.oDim2AllcRowId = oDim2AllcBindingContextPath[oDim2AllcRowId];

		sap.ui.getCore().byId("Dim2AllcListTable").removeSelections();
		this.oDim2AllcDialog.setModel(this.oModel);
		$.ajax({
			url: "OData/CostCenter.xsodata/CostCenter?$filter=DMCode eq '2'",
			xhrFields: {
				withCredentials: true
			},
			async: false,
			type: "GET",
			dataType: "json",
			success: function(oData, oResponse) {
				var aItemsData = oData.d.results; //oData.value;
				for (var m = 0; m < aItemsData.length; m++) {
					aItemsData[m].Amount = "0";
				}
				that.oModel.getData().Dim2AllcList = oData.d.results;
				that.oModel.refresh();
				that.oDim2AllcDialog.open();
			},
			error: function(oError) {
				sap.m.MessageToast.show("Error: " + oError);
			}
		});
	},*/

	/*handleDim2AllcOk: function(oEvent) {
		var oDim2AllcListTable = sap.ui.getCore().byId("Dim2AllcListTable");
		var oSelectedDim2 = oDim2AllcListTable.getSelectedItem();
		//var oItems = this.oModel.getData().GrantRevenueDetails;

		if (oSelectedDim2) {
			var oSelctedCustContext = oSelectedDim2.getBindingContext();
			var path = oSelctedCustContext.sPath;
			var Dim2 = this.oModel.getProperty(path);
			this.oModel.setProperty("/GrantRevenueAllocation/" + this.oDim2AllcRowId + "/U_AllcSub", Dim2.CCCode);
			this.oModel.setProperty("/GrantRevenueAllocation/" + this.oDim2AllcRowId + "/U_AlSubNm", Dim2.CCName);

			//this.oModel.setProperty("/GrantRevenueAllocation/" + this.oDim2RowId + "/U_ReSubNm", Dim2.CCName);
			this.oModel.refresh();
			sap.ui.getCore().byId("Dim2AllcListTable").removeSelections();
			this.oDim2AllcDialog.close();
		} else {
			sap.m.MessageToast.show("Please select Dimension");
		}

		//this.oModel.getData().GrantRevenueDetails = oItems;

	},*/

	/*handleDim2AllcClose: function(oEvent) {
		this.oDim2AllcDialog.close();
	},*/

	handleDim3: function(oEvent) {
		var that = this;
		if (!this.oDim3Dialog) {
			this.oDim3Dialog = sap.ui.xmlfragment("SLFiori.fragments.Dim3", this);
		}
		this.oDim3 = "";
		var oDim3BindingContextPath = oEvent.getSource().getBindingContext().sPath.split("/");
		var aDim3SelectedPathLength = oDim3BindingContextPath.length;
		var oDim3RowId = aDim3SelectedPathLength - 1;
		this.oDim3RowId = oDim3BindingContextPath[oDim3RowId];

		sap.ui.getCore().byId("Dim3ListTable").removeSelections();
		this.oDim3Dialog.setModel(this.oModel);

		var oAmtBindingContextPath = oEvent.getSource().getBindingContext().sPath;
		//this.oModel.setProperty(oAmtBindingContextPath + "/U_RevenSub", oEvent.oSource.getValue());
		var SubLoc = this.oModel.getProperty(oAmtBindingContextPath + "/U_FrzSub");

		$.ajax({
			url: "OData/CostCenter.xsodata/CostCenter?$filter=U_SubCode eq '" + SubLoc +
				"'",
			xhrFields: {
				withCredentials: true
			},
			async: false,
			type: "GET",
			dataType: "json",
			success: function(oData, oResponse) {
				var aItemsData = oData.d.results; //oData.value;
				for (var m = 0; m < aItemsData.length; m++) {
					aItemsData[m].Amount = "0";
				}
				that.oModel.getData().Dim3List = oData.d.results;
				that.oModel.refresh();
				that.oDim3Dialog.open();
			},
			error: function(oError) {
				sap.m.MessageToast.show("Error: " + oError);
			}
		});
	},

	handleDim3Ok: function(oEvent) {
		var oDim3ListTable = sap.ui.getCore().byId("Dim3ListTable");
		var oSelectedDim3 = oDim3ListTable.getSelectedItem();
		//var oItems = this.oModel.getData().GrantRevenueDetails;

		if (oSelectedDim3) {
			var oSelctedCustContext = oSelectedDim3.getBindingContext();
			var path = oSelctedCustContext.sPath;
			var Dim3 = this.oModel.getProperty(path);
			//this.oModel.setProperty("/TaxCode", Tax.Code);

			this.oModel.setProperty("/FreezingDetails/" + this.oDim3RowId + "/U_FrzLoc", Dim3.CCCode);
			this.oModel.setProperty("/FreezingDetails/" + this.oDim3RowId + "/U_FrLocNm", Dim3.CCName);
			this.oModel.refresh();
			sap.ui.getCore().byId("Dim3ListTable").removeSelections();
			this.oDim3Dialog.close();
		} else {
			sap.m.MessageToast.show("Please select Dimension");
		}
		//this.oModel.getData().GrantRevenueDetails = oItems;

	},

	handleDim3Close: function(oEvent) {
		this.oDim3Dialog.close();
	},

/*	handleAllcDim3: function(oEvent) {
		var that = this;
		if (!this.oDim3AllcDialog) {
			this.oDim3AllcDialog = sap.ui.xmlfragment("SLFiori.fragments.Dim3_AllocationV1", this);
		}
		this.oDim3 = "";
		var oDim3AllcBindingContextPath = oEvent.getSource().getBindingContext().sPath.split("/");
		var aDim3AllcSelectedPathLength = oDim3AllcBindingContextPath.length;
		var oDim3AllcRowId = aDim3AllcSelectedPathLength - 1;
		this.oDim3AllcRowId = oDim3AllcBindingContextPath[oDim3AllcRowId];

		sap.ui.getCore().byId("Dim3AllcListTable").removeSelections();
		this.oDim3AllcDialog.setModel(this.oModel);

		var oAmtBindingContextPath = oEvent.getSource().getBindingContext().sPath;
		//this.oModel.setProperty(oAmtBindingContextPath + "/U_RevenSub", oEvent.oSource.getValue());
		var SubLoc = this.oModel.getProperty(oAmtBindingContextPath + "/U_AllcSub");

		$.ajax({
			url: "OData/CostCenter.xsodata/CostCenter?$filter=U_SubCode eq '" + SubLoc +
				"'",
			xhrFields: {
				withCredentials: true
			},
			async: false,
			type: "GET",
			dataType: "json",
			success: function(oData, oResponse) {
				var aItemsData = oData.d.results; //oData.value;
				for (var m = 0; m < aItemsData.length; m++) {
					aItemsData[m].Amount = "0";
				}
				that.oModel.getData().Dim3AllcList = oData.d.results;
				that.oModel.refresh();
				that.oDim3AllcDialog.open();
			},
			error: function(oError) {
				sap.m.MessageToast.show("Error: " + oError);
			}
		});
	},*/

/*	handleDim3AllcOk: function(oEvent) {
		var oDim3AllcListTable = sap.ui.getCore().byId("Dim3AllcListTable");
		var oSelectedDim3 = oDim3AllcListTable.getSelectedItem();
		//var oItems = this.oModel.getData().GrantRevenueDetails;

		if (oSelectedDim3) {
			var oSelctedCustContext = oSelectedDim3.getBindingContext();
			var path = oSelctedCustContext.sPath;
			var Dim3 = this.oModel.getProperty(path);
			this.oModel.setProperty("/GrantRevenueAllocation/" + this.oDim3AllcRowId + "/U_AllcLoc", Dim3.CCCode);
			this.oModel.setProperty("/GrantRevenueAllocation/" + this.oDim3AllcRowId + "/U_AlLocNm", Dim3.CCName);
			//this.oModel.setProperty("/GrantRevenueAllocation/" + this.oDim2RowId + "/U_ReSubNm", Dim2.CCName);
			this.oModel.refresh();
			sap.ui.getCore().byId("Dim3AllcListTable").removeSelections();
			this.oDim3AllcDialog.close();
		} else {
			sap.m.MessageToast.show("Please select Dimension");
		}

		//this.oModel.getData().GrantRevenueDetails = oItems;

	},*/

/*	handleDim3AllcClose: function(oEvent) {
		this.oDim3AllcDialog.close();
	},*/

	handleDim4: function(oEvent) {
		var that = this;
		if (!this.oDim4Dialog) {
			this.oDim4Dialog = sap.ui.xmlfragment("SLFiori.fragments.Dim4", this);
		}
		this.oDim4 = "";
		var oDim4BindingContextPath = oEvent.getSource().getBindingContext().sPath.split("/");
		var aDim4SelectedPathLength = oDim4BindingContextPath.length;
		var oDim4RowId = aDim4SelectedPathLength - 1;
		this.oDim4RowId = oDim4BindingContextPath[oDim4RowId];

		sap.ui.getCore().byId("Dim4ListTable").removeSelections();
		this.oDim4Dialog.setModel(this.oModel);
		$.ajax({
			url: "OData/CostCenter.xsodata/CostCenter?$filter=DMCode eq '4'",
			xhrFields: {
				withCredentials: true
			},
			async: false,
			type: "GET",
			dataType: "json",
			success: function(oData, oResponse) {
				var aItemsData = oData.d.results; //oData.value;
				for (var m = 0; m < aItemsData.length; m++) {
					aItemsData[m].Amount = "0";
				}
				that.oModel.getData().Dim4List = oData.d.results;
				that.oModel.refresh();
				that.oDim4Dialog.open();
			},
			error: function(oError) {
				sap.m.MessageToast.show("Error: " + oError);
			}
		});
	},

	handleDim4Ok: function(oEvent) {
		var oDim4ListTable = sap.ui.getCore().byId("Dim4ListTable");
		var oSelectedDim4 = oDim4ListTable.getSelectedItem();
		if (oSelectedDim4) {
			var oSelctedCustContext = oSelectedDim4.getBindingContext();
			var path = oSelctedCustContext.sPath;
			var Dim4 = this.oModel.getProperty(path);
			//this.oModel.setProperty("/TaxCode", Tax.Code);
			this.oModel.setProperty("/FreezingDetails/" + this.oDim4RowId + "/U_FrzPgm", Dim4.CCCode);
			this.oModel.setProperty("/FreezingDetails/" + this.oDim4RowId + "/U_FrPgmNm", Dim4.CCName);
			this.oModel.refresh();
			sap.ui.getCore().byId("Dim4ListTable").removeSelections();
			this.oDim4Dialog.close();
		} else {
			sap.m.MessageToast.show("Please select Dimension");
		}

	},

	handleDim4Close: function(oEvent) {
		this.oDim4Dialog.close();
	},

	handleDim5: function(oEvent) {
		var that = this;
		if (!this.oDim5Dialog) {
			this.oDim5Dialog = sap.ui.xmlfragment("SLFiori.fragments.Dim5", this);
		}
		this.oDim5 = "";
		var oDim5BindingContextPath = oEvent.getSource().getBindingContext().sPath.split("/");
		var aDim5SelectedPathLength = oDim5BindingContextPath.length;
		var oDim5RowId = aDim5SelectedPathLength - 1;
		this.oDim5RowId = oDim5BindingContextPath[oDim5RowId];

		sap.ui.getCore().byId("Dim5ListTable").removeSelections();
		this.oDim5Dialog.setModel(this.oModel);
		$.ajax({
			url: "OData/CostCenter.xsodata/CostCenter?$filter=DMCode eq '5'",
			xhrFields: {
				withCredentials: true
			},
			async: false,
			type: "GET",
			dataType: "json",
			success: function(oData, oResponse) {
				var aItemsData = oData.d.results; //oData.value;
				for (var m = 0; m < aItemsData.length; m++) {
					aItemsData[m].Amount = "0";
				}
				that.oModel.getData().Dim5List = oData.d.results;
				that.oModel.refresh();
				that.oDim5Dialog.open();
			},
			error: function(oError) {
				sap.m.MessageToast.show("Error: " + oError);
			}
		});
	},

	handleDim5Ok: function(oEvent) {
		var oDim5ListTable = sap.ui.getCore().byId("Dim5ListTable");
		var oSelectedDim5 = oDim5ListTable.getSelectedItem();
		if (oSelectedDim5) {
			var oSelctedCustContext = oSelectedDim5.getBindingContext();
			var path = oSelctedCustContext.sPath;
			var Dim5 = this.oModel.getProperty(path);
			//this.oModel.setProperty("/TaxCode", Tax.Code);
			this.oModel.setProperty("/FreezingDetails/" + this.oDim5RowId + "/U_GrInit", Dim5.CCCode);
			this.oModel.setProperty("/FreezingDetails/" + this.oDim5RowId + "/U_GrIntNm", Dim5.CCName);
			this.oModel.refresh();
			sap.ui.getCore().byId("Dim5ListTable").removeSelections();
			this.oDim5Dialog.close();
		} else {
			sap.m.MessageToast.show("Please select Dimension");
		}

	},

	handleDim5Close: function(oEvent) {
		this.oDim5Dialog.close();
	},

	handleRevenueType: function(oEvent) {
		var that = this;
		if (!this.oRevTypeDialog) {
			this.oRevTypeDialog = sap.ui.xmlfragment("SLFiori.fragments.RevenueType", this);
		}
		this.oRevType = "";
		var oRevTypeBindingContextPath = oEvent.getSource().getBindingContext().sPath.split("/");
		var aRevTypeSelectedPathLength = oRevTypeBindingContextPath.length;
		var oRevTypeRowId = aRevTypeSelectedPathLength - 1;
		this.oRevTypeRowId = oRevTypeBindingContextPath[oRevTypeRowId];

		sap.ui.getCore().byId("RevTypeListTable").removeSelections();
		this.oRevTypeDialog.setModel(this.oModel);
		$.ajax({
			url: "OData/RevenueType.xsodata/RevenueType",
			xhrFields: {
				withCredentials: true
			},
			async: false,
			type: "GET",
			dataType: "json",
			success: function(oData, oResponse) {
				var aItemsData = oData.d.results; //oData.value;
				for (var m = 0; m < aItemsData.length; m++) {
					aItemsData[m].Amount = "0";
				}
				that.oModel.getData().RevTypeList = oData.d.results;
				that.oModel.refresh();
				that.oRevTypeDialog.open();
			},
			error: function(oError) {
				sap.m.MessageToast.show("Error: " + oError);
			}
		});
	},

	handleRevTypeOk: function(oEvent) {
		var oRevTypeListTable = sap.ui.getCore().byId("RevTypeListTable");
		var oSelectedRevType = oRevTypeListTable.getSelectedItem();
		if (oSelectedRevType) {
			var oSelctedCustContext = oSelectedRevType.getBindingContext();
			var path = oSelctedCustContext.sPath;
			var RevType = this.oModel.getProperty(path);
			//this.oModel.setProperty("/TaxCode", Tax.Code);
			this.oModel.setProperty("/GrantRevenueDetails/" + this.oRevTypeRowId + "/U_RevenTyp", RevType.U_RevTyp);
			this.oModel.refresh();
			sap.ui.getCore().byId("RevTypeListTable").removeSelections();
			this.oRevTypeDialog.close();
		} else {
			sap.m.MessageToast.show("Please select Revenue Type");
		}

	},

	handleRevTypeClose: function(oEvent) {
		this.oRevTypeDialog.close();
	},

	handleGrantCurrency: function(oEvent) {
		var that = this;
		if (!this.oCurrencyrDialog) {
			this.oCurrencyrDialog = sap.ui.xmlfragment("SLFiori.fragments.CurrencyMasterV1", this);
		}
		sap.ui.getCore().byId("CurrencyListTable").removeSelections();
		this.oCurrencyrDialog.setModel(this.oModel);
		$.ajax({
			//url: "https://172.31.28.160:50000/b1s/v1/BusinessPartners?$select=CardCode,CardName,CntctPrsn,Cellular&$filter=CardType eq 'C'",
			//url: "https://172.31.28.160:50000/b1s/v1/BusinessPartners?$select=CardCode,CardName,ContactPerson,Cellular",
			url: "OData/GrantContract_Currencies.xsodata/Currency",
			xhrFields: {
				withCredentials: true
			},
			async: false,
			type: "GET",
			dataType: "json",
			success: function(oData, oResponse) {
				that.oModel.getData().CurrencyList = oData.d.results; //oData.value;
				that.oModel.refresh();
				that.oCurrencyrDialog.open();
			},
			error: function(oError) {
				sap.m.MessageToast.show("Error: " + oError);
			}
		});
	},

	handleCurrencyOk: function(oEvent) {
		var oDonorListTable = sap.ui.getCore().byId("CurrencyListTable");
		var oSelectedDonor = oDonorListTable.getSelectedItem();
		if (oSelectedDonor) {
			var oSelctedCustContext = oSelectedDonor.getBindingContext();
			var path = oSelctedCustContext.sPath;
			var Donor = this.oModel.getProperty(path);
			this.oModel.setProperty("/GrantCur", Donor.CurrCode);
			//this.oModel.setProperty("/DnrNam", Donor.CardName);
			//this.oModel.setProperty("/DonorCnt", Donor.CntctPrsn);
			//this.oModel.setProperty("/TelNo", Donor.Cellular);

			this.oModel.refresh();
			sap.ui.getCore().byId("CurrencyListTable").removeSelections();
			this.oCurrencyrDialog.close();
		} else {
			sap.m.MessageToast.show("Please select Currency");
		}
	},

	handleCurrencyClose: function() {
		sap.ui.getCore().byId("CurrencyListTable").removeSelections();
		this.oCurrencyrDialog.close();
	},

	handlek: function(oEvent) {

		var oItemListTable = sap.ui.getCore().byId("itemListTable");
		var aSelectedItems = oItemListTable.getSelectedItems();
		var oItems = this.oModel.getData().selectedItemList;

		for (var i = 0; i < aSelectedItems.length; i++) {
			var oBindingContextPath = aSelectedItems[i].getBindingContextPath().split("/");
			var aSelectedPathLength = oBindingContextPath.length;
			var oRowId = aSelectedPathLength - 1;
			var iIndex = oBindingContextPath[oRowId];
			oItems.push(this.oModel.getData().itemList[iIndex]);
		}
		//this.oModel.setProperty("selectedItemList", aSelectedItems);
		//this.oModel.setProperty("/selectedItemList/ItemCode", oItems.ItemCode);
		this.oModel.getData().selectedItemList = oItems;
		this.oModel.refresh();
		this.oItemListDialog.close();
	}

});