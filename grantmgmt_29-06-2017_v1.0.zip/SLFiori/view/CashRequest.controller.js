sap.ui.controller("SLFiori.view.CashRequest", {

	onInit: function() {
		this.router = sap.ui.core.UIComponent.getRouterFor(this);
		this.router.attachRoutePatternMatched(this._handleRouteMatched, this);
		this.GrantEntry = "";
		//this.getRouter().attachRoutePatternMatched(this.onRouteMatched, this);

		this.NewEntry = {
			FormMode: "Add",
			ReqTyp: "",
			DocNum: "",
			ReqDate: new Date(),
			Status: "Open",
			DueDate: "",
			ReqNam: "",
			ReqID: "",
			ReqSub: "",
			ReqLoc: "",
			RcBnCnt: "",
			RcBnNm: "",
			BnAcNo: "",
			BnSwNo: "",
			IBAN: "",
			Rmks: "",
			RequestForm: [
				{
					LineId: "1",
					U_ReqTyp: "",
					U_Code: "",
					U_Name: "",
					U_GrFrNo: "",
					U_ExRate: "",
					U_PaySub: "",
					U_PayLoc: "",
					U_ReqCurr: "",
					U_Amount: "",
					U_PaySts: ""
				}
                      ],
			ComboList: [{
				key: "C",
				value: "Closed"
			}, {
				key: "O",
				value: "Open"
			}, {
				key: "R",
				value: "Released"
			}]

			// 			ComboYesNo: [{
			// 				key: "Yes",
			// 				value: "Yes"
			// 			}, {
			// 				key: "No",
			// 				value: "No"
			// 			}],

		};

		this.list = {
			FormMode: "Update",
			ReqTyp: "",
			DocNum: "",
			ReqDate: new Date(),
			Status: "Open",
			DueDate: "",
			ReqNam: "",
			ReqID: "",
			ReqSub: "",
			ReqLoc: "",
			RcBnCnt: "",
			RcBnNm: "",
			BnAcNo: "",
			BnSwNo: "",
			IBAN: "",
			Rmks: "",
			RequestForm: [
				{
					LineId: "1",
					U_ReqTyp: "",
					U_Code: "",
					U_Name: "",
					U_GrFrNo: "",
					U_ExRate: "",
					U_PaySub: "",
					U_PayLoc: "",
					U_ReqCurr: "",
					U_Amount: "",
					U_PaySts: ""
				}
                      ],
			ComboList: [{
				key: "C",
				value: "Closed"
			}, {
				key: "O",
				value: "Open"
			}, {
				key: "R",
				value: "Released"
			}]

			// 			ComboYesNo: [{
			// 				key: "Yes",
			// 				value: "Yes"
			// 			}, {
			// 				key: "No",
			// 				value: "No"
			// 			}],

		};

		this.oModel = new sap.ui.model.json.JSONModel(this.list);
		this.getView().setModel(this.oModel);
	},

	handleSaveGrantContract: function(oEvent) {

		/*var jData =  JSON.stringify({CardCode:"C20000",
		                            DocumentLines:[{ItemCode:"A00001",TaxCode:"VAT@4",Quantity:"110","UnitPrice":"20"}]
		});*/
		var oModelData = this.oModel.getData();

		var that = this;

		var oResults = oModelData.GrantRevenueDetails;
		for (var i = 0; i < oResults.length; i++) {
			delete oResults[i].RowEnable;
			delete oResults[i].RowVisible;
		}

		var jData = JSON.stringify({
			U_SFDCOppN: oModelData.SFDCOppN,
			U_GCrDate: oModelData.GCrDate,
			U_Status: oModelData.Status,
			U_DnrCod: oModelData.DnrCod,
			U_DnrNam: oModelData.DnrNam,
			U_DSFDCId: oModelData.DSFDCId,
			U_GCType: oModelData.GCType,

			//U_CommGrnt: oModelData.CommGrnt,

			U_GCFrom: oModelData.GCFrom,
			U_GCTo: oModelData.GCTo,
			U_GCAmt: oModelData.GCAmt,
			U_GCode: oModelData.GCode,
			U_GName: oModelData.GName,
			U_GrantCur: oModelData.GrantCur,
			U_GrRes: oModelData.GrRes,
			U_GrFinMan: oModelData.GrFinMan,
			U_GMan: oModelData.GMan,
			U_Rmks: oModelData.Rmks,
			U_Athmnt: oModelData.Athmnt,

			//			U_GDate: oModelData.GDate,
			U_GSCCov: oModelData.GSCCov,
			U_GSCCovPr: oModelData.GSCCovPr,
			//U_GRelsSt: oModelData.GRelsSt,

			//"IK_NCT1Collection":[{U_RevenSub:oModelData.GrantRevenueDetails.RevenSub}]
			"IK_NCT1Collection": oModelData.GrantRevenueDetails,
			//"IK_NCT2Collection": oModelData.GrantPaymentSchedule,
			"IK_NCT3Collection": oModelData.GrantRevenueAllocation
			//"IK_NCT4Collection":oModelData.GrantInitiative,
			//"IK_NCT5Collection":oModelData.GrantReporting
		});
		//var CardCode = this.byId("sId")

		if (oModelData.FormMode !== "Add") {
			//sap.m.MessageToast.show("FormMode-Update");
			//this.GrantEntry=data.mParameters.arguments.Key;
			$.ajax({
				//url: "https://10.0.1.189:50000/b1s/v1/IK_GNCT(" + oModelData.GrantEntryNo + ")",
				url: "/b1s/v1/IK_GNCT(" + oModelData.GrantEntryNo + ")",
				xhrFields: {
					withCredentials: true
				},
				beforeSend: function(xhr) {
					xhr.setRequestHeader("B1S-ReplaceCollectionsOnPatch", "true");
				},
				data: jData,
				type: "PATCH",
				dataType: "json",
				success: function(json) {
					sap.m.MessageToast.show("Grant Contract Updated Sucessfully");
				},
				error: function(xhr, status, errorThrown) {
					sap.m.MessageToast.show("Error: " + xhr.responseJSON.error.message.value);
				},
				complete: function(xhr, status) {}
			});

			var formData = new FormData();
			formData.append('files', $(test)[0].files[0]);

			$.ajax({
				//url: "https://10.0.1.189:50000/b1s/v1/IK_GNCT(" + oModelData.GrantEntryNo + ")",
				url: "/b1s/v1/Attachments2",
				data: formData,
				type: "POST",
				processData: false,
				contentType: false,
				dataType: "json",
				success: function(json) {
					sap.m.MessageToast.show("Attachment Updated Sucessfully");
				},
				error: function(xhr, status, errorThrown) {
					sap.m.MessageToast.show("Error: " + xhr.responseJSON.error.message.value);
				},
				complete: function(xhr, status) {}
			});
		} else {
			//sap.m.MessageToast.show("FormMode-Add");
			$.ajax({

				//url: "https://10.0.1.189:50000/b1s/v1/IK_GNCT",
				url: "/b1s/v1/IK_GNCT",
				xhrFields: {
					withCredentials: true
				},
				data: jData,
				type: "POST",
				dataType: "json",
				success: function(json) {
					sap.m.MessageToast.show("Grant Contract Posted Sucessfully");
				},
				error: function(xhr, status, errorThrown) {
					sap.m.MessageToast.show("Error: " + xhr.responseJSON.error.message.value);
				},
				complete: function(xhr, status) {}
			});
		}

	},

	handleAddEntry: function() {
		//var oPanel = this.getView().byId("_HBox");
		//oPanel.setBusy(true);

		var oDialog = this.getView().byId("BusyDialog");
		oDialog.open();

		this.oModel = new sap.ui.model.json.JSONModel(this.NewEntry);
		this.getView().setModel(this.oModel);

		//oPanel.setBusy(false);
	},

	_handleRouteMatched: function(data) {
		this.GrantEntry = data.mParameters.arguments.Key;

		if (this.GrantEntry === "0") {
			//var oPanel = this.getView().byId("_HBox");
			//oPanel.setBusy(true);

			this.oModel = new sap.ui.model.json.JSONModel(this.NewEntry);
			this.getView().setModel(this.oModel);

			//oPanel.setBusy(false);
		} else {

			var oParameter = data.getParameter("name");
			if (oParameter !== "GrantContract") {
				return;
			}
			var oModelData = this.oModel.getData();
			var that = this;
			$.ajax({
				// 			url: "http://10.0.1.189:8000/Ashoka/SAPUI5/WebContent/org/edu/ui/OData/GrantContract_Header.xsodata/GrantContract?$filter=DocEntry eq '" +
				// 				this.GrantEntry + "'",
				url: "OData/GrantContract_Header.xsodata/GrantContract?$filter=DocEntry eq '" + this.GrantEntry + "'",
				xhrFields: {
					withCredentials: true
				},
				async: false,
				type: "GET",
				dataType: "json",
				success: function(oData, oResponse) {
					var oResults = oData.d.results;
					for (var i = 0; i < oResults.length; i++) {
						delete oResults[i].__metadata;
					}
					//that.oModel.getData().GrantRevenueDetails = oResults;
					that.oModel.setProperty("/GrantEntryNo", oData.d.results[0].DocEntry);
					that.oModel.setProperty("/GCDocNum", oData.d.results[0].DocNum);
					that.oModel.setProperty("/GCode", oData.d.results[0].GCode);
					that.oModel.setProperty("/GName", oData.d.results[0].U_GName);
					that.oModel.setProperty("/DnrCod", oData.d.results[0].U_DnrCod);
					that.oModel.setProperty("/DnrNam", oData.d.results[0].U_DnrNam);
					that.oModel.setProperty("/DSFDCId", oData.d.results[0].U_DSFDCId);
					that.oModel.setProperty("/CommGrnt", oData.d.results[0].U_CommGrnt);
					that.oModel.setProperty("/GCrDate", oData.d.results[0].U_GCrDate);
					//that.oModel.setProperty("/GCrDate", "2017-04-25");
					that.oModel.setProperty("/Status", oData.d.results[0].U_Status);
					that.oModel.setProperty("/SFDCOppN", oData.d.results[0].U_SFDCOppN);
					that.oModel.setProperty("/GrantCur", oData.d.results[0].U_GrantCur);
					that.oModel.setProperty("/GCAmt", oData.d.results[0].U_GCAmt);
					that.oModel.setProperty("/GDate", oData.d.results[0].U_GDate);
					that.oModel.setProperty("/GSCCov", oData.d.results[0].U_GSCCov);
					that.oModel.setProperty("/GSCCovPr", oData.d.results[0].U_GSCCovPr);
					that.oModel.setProperty("/GRelsSt", oData.d.results[0].U_GRelsSt);
					that.oModel.setProperty("/GCFrom", oData.d.results[0].U_GCFrom);
					//that.oModel.setProperty("/GCFrom", "2017-04-25");
					that.oModel.setProperty("/GCTo", oData.d.results[0].U_GCTo);
					that.oModel.setProperty("/GrFinMan", oData.d.results[0].U_GrFinMan);
					that.oModel.setProperty("/GMan", oData.d.results[0].U_GMan);
					that.oModel.setProperty("/Athmnt", oData.d.results[0].U_Athmnt);
					that.oModel.setProperty("/Rmks", oData.d.results[0].U_Rmks);
					that.oModel.setProperty("/GCType", oData.d.results[0].U_GCType);
					that.oModel.setProperty("/GrRes", oData.d.results[0].U_GrRes);

					that.oModel.refresh();
				},
				error: function(oError) {
					sap.m.MessageToast.show("Error: " + oError.responseJSON.error.message.value);
				}
			});

			$.ajax({
				// 			url: "http://10.0.1.189:8000/Ashoka/SAPUI5/WebContent/org/edu/ui/OData/GrantContract_RevenueDetails.xsodata/GrantContract?$filter=DocEntry eq '" +
				// 				this.GrantEntry + "'&$orderby=LineId asc",
				url: "OData/GrantContract_RevenueDetails.xsodata/GrantContract?$filter=DocEntry eq '" + this.GrantEntry + "'&$orderby=LineId asc",
				xhrFields: {
					withCredentials: true
				},
				async: false,
				type: "GET",
				dataType: "json",
				success: function(oData, oResponse) {
					var oResults = oData.d.results;
					for (var i = 0; i < oResults.length; i++) {
						delete oResults[i].__metadata;
					}
					that.oModel.getData().GrantRevenueDetails = oResults;
					that.oModel.refresh();
				},
				error: function(oError) {
					sap.m.MessageToast.show("Error: " + oError.responseJSON.error.message.value);
				}
			});

			$.ajax({
				// 			url: "http://10.0.1.189:8000/Ashoka/SAPUI5/WebContent/org/edu/ui/OData/GrantContract_RevenueAllocation.xsodata/GrantContract?$filter=DocEntry eq '" +
				// 				this.GrantEntry + "'&$orderby=LineId asc",
				url: "OData/GrantContract_RevenueAllocation.xsodata/GrantContract?$filter=DocEntry eq '" + this.GrantEntry + "'&$orderby=LineId asc",
				xhrFields: {
					withCredentials: true
				},
				async: false,
				type: "GET",
				dataType: "json",
				success: function(oData, oResponse) {
					var oResults = oData.d.results;
					for (var i = 0; i < oResults.length; i++) {
						delete oResults[i].__metadata;
					}
					that.oModel.getData().GrantRevenueAllocation = oResults;
					that.oModel.refresh();
				},
				error: function(oError) {
					sap.m.MessageToast.show("Error: " + oError.responseJSON.error.message.value);
				}
			});

			// 		$.ajax({
			// 			url: "http://10.0.1.189:8000/Ashoka/SAPUI5/WebContent/org/edu/ui/OData/GrantContract_PaymentSchedule.xsodata/GrantContract?$filter=DocEntry eq '" +
			// 				this.GrantEntry + "'",
			// 			xhrFields: {
			// 				withCredentials: true
			// 			},
			// 			async: false,
			// 			type: "GET",
			// 			dataType: "json",
			// 			success: function(oData, oResponse) {
			// 				var oResults = oData.d.results;
			// 				for (var i = 0; i < oResults.length; i++) {
			// 					delete oResults[i].__metadata;
			// 				}
			// 				that.oModel.getData().GrantPaymentSchedule = oResults;
			// 				that.oModel.refresh();
			// 			},
			// 			error: function(oError) {
			// 				sap.m.MessageToast.show("Error: " + oError);
			// 			}
			// 		});

		}
	},

	onAfterRendering: function() {
		//this.byId("idProductsTable").setWidths(["30%", "70%"]);
		//var that = this;
		// if (sap.m.ComboBox.prototype.onAfterRendering) {
		//   sap.m.ComboBox.prototype.onAfterRendering.apply(that);
		// }
		//this.byId("Status-inner").disabled=true;

	},

	onBack: function() {
		var that = this;
		that.router.navTo("Dashboard");
	},

	handleDonorList: function(oEvent) {
		var that = this;
		if (!this.oDonorMasterDialog) {
			this.oDonorMasterDialog = sap.ui.xmlfragment("SLFiori.fragments.DonorMasterV3", this);
		}
		sap.ui.getCore().byId("DonorListTable").removeSelections();
		this.oDonorMasterDialog.setModel(this.oModel);
		$.ajax({
			//url: "https://10.0.1.189:50000/b1s/v1/BusinessPartners?$select=CardCode,CardName,ContactPerson,Cellular,EmailAddress&$filter=Valid eq 'Y' and Frozen eq 'N' &$top=1000&$orderby=CardName",
			url: "/b1s/v1/BusinessPartners?$select=CardCode,CardName,ContactPerson,Cellular,EmailAddress&$filter=Valid eq 'Y' and Frozen eq 'N' and CardType eq 'C' &$top=1000&$orderby=CardName",
			xhrFields: {
				withCredentials: true
			},
			async: false,
			type: "GET",
			dataType: "json",
			success: function(oData, oResponse) {
				that.oModel.getData().DonorList = oData.value;
				that.oModel.refresh();
				that.oDonorMasterDialog.open();
			},
			error: function(oError) {
				sap.m.MessageToast.show("Error: " + oError.responseJSON.error.message.value);
			}
		});
	},

	handleCustOk: function(oEvent) {
		var oDonorListTable = sap.ui.getCore().byId("DonorListTable");
		var oSelectedDonor = oDonorListTable.getSelectedItem();
		if (oSelectedDonor) {
			var oSelctedCustContext = oSelectedDonor.getBindingContext();
			var path = oSelctedCustContext.sPath;
			var Donor = this.oModel.getProperty(path);
			this.oModel.setProperty("/DnrCod", Donor.CardCode);
			this.oModel.setProperty("/DnrNam", Donor.CardName);
			//this.oModel.setProperty("/DonorCnt", Donor.CntctPrsn);
			//this.oModel.setProperty("/TelNo", Donor.Cellular);

			this.oModel.refresh();
			sap.ui.getCore().byId("DonorListTable").removeSelections();
			this.oDonorMasterDialog.close();
		} else {
			sap.m.MessageToast.show("Please select Donor");
		}
	},

	handleCustClose: function() {
		sap.ui.getCore().byId("DonorListTable").removeSelections();
		this.oDonorMasterDialog.close();
	},

	handleGrantCurrency: function(oEvent) {
		var that = this;
		if (!this.oCurrencyrDialog) {
			this.oCurrencyrDialog = sap.ui.xmlfragment("SLFiori.fragments.CurrencyMasterV1", this);
		}
		sap.ui.getCore().byId("CurrencyListTable").removeSelections();
		this.oCurrencyrDialog.setModel(this.oModel);
		$.ajax({
			//url: "https://172.31.28.160:50000/b1s/v1/BusinessPartners?$select=CardCode,CardName,CntctPrsn,Cellular&$filter=CardType eq 'C'",
			//url: "https://172.31.28.160:50000/b1s/v1/BusinessPartners?$select=CardCode,CardName,ContactPerson,Cellular",
			//url: "http://10.0.1.189:8000/Ashoka/SAPUI5/WebContent/org/edu/ui/OData/GrantContract_Currencies.xsodata/Currency",
			url: "OData/GrantContract_Currencies.xsodata/Currency",
			xhrFields: {
				withCredentials: true
			},
			async: false,
			type: "GET",
			dataType: "json",
			success: function(oData, oResponse) {
				that.oModel.getData().CurrencyList = oData.d.results; //oData.value;
				that.oModel.refresh();
				that.oCurrencyrDialog.open();
			},
			error: function(oError) {
				sap.m.MessageToast.show("Error: " + oError.responseJSON.error.message.value);
			}
		});
	},

	handleCurrencyOk: function(oEvent) {
		var oDonorListTable = sap.ui.getCore().byId("CurrencyListTable");
		var oSelectedDonor = oDonorListTable.getSelectedItem();
		if (oSelectedDonor) {
			var oSelctedCustContext = oSelectedDonor.getBindingContext();
			var path = oSelctedCustContext.sPath;
			var Donor = this.oModel.getProperty(path);
			this.oModel.setProperty("/GrantCur", Donor.CurrCode);
			//this.oModel.setProperty("/DnrNam", Donor.CardName);
			//this.oModel.setProperty("/DonorCnt", Donor.CntctPrsn);
			//this.oModel.setProperty("/TelNo", Donor.Cellular);

			this.oModel.refresh();
			sap.ui.getCore().byId("CurrencyListTable").removeSelections();
			this.oCurrencyrDialog.close();
		} else {
			sap.m.MessageToast.show("Please select Currency");
		}
	},

	handleCurrencyClose: function() {
		sap.ui.getCore().byId("CurrencyListTable").removeSelections();
		this.oCurrencyrDialog.close();
	},

	handleAmountLiveChange: function(oEvent) {
		var oAmtBindingContextPath = oEvent.getSource().getBindingContext().sPath;
		this.oModel.setProperty(oAmtBindingContextPath + "/U_Amount", oEvent.oSource.getValue());
		this.oModel.refresh();
		this.onAmountChange(oAmtBindingContextPath);
	},

	onAmountChange: function(oContext) {
		var Price = this.oModel.getProperty(oContext + "/U_Amount");
		var Total = Price;
		var oItems = this.oModel.getData().GrantRevenueDetails;
		var DocTotal = 0;
		for (var i = 0; i < oItems.length; i++) {
			DocTotal = DocTotal + ((oItems[i].U_Amount === "") ? 0 : parseFloat(oItems[i].U_Amount));
		}
		this.oModel.setProperty("/GCAmt", DocTotal);
		this.oModel.refresh();
	},

	handleAllocationLiveChange: function(oEvent) {
		var oAmtBindingContextPath = oEvent.getSource().getBindingContext().sPath;
		this.oModel.setProperty(oAmtBindingContextPath + "/U_Amt", oEvent.oSource.getValue());
		this.oModel.refresh();
		this.onAllocationChange(oAmtBindingContextPath);
	},

	onAllocationChange: function(oContext) {
		var Price = this.oModel.getProperty(oContext + "/U_Amt");
		var oItems = this.oModel.getData().GrantRevenueAllocation;
		var Allocated = 0;
		for (var i = 0; i < oItems.length; i++) {
			Allocated = Allocated + ((oItems[i].U_Amt === "") ? 0 : parseFloat(oItems[i].U_Amt));
		}
		var LineNum = this.oModel.getProperty(oContext + "/U_GRevLNo") - 1;
		var oGrRevDet = this.oModel.getData().GrantRevenueDetails;
		var AllcAmt = 0;
		AllcAmt = AllcAmt + ((oGrRevDet[LineNum].U_Amount === "") ? 0 : parseFloat(oGrRevDet[LineNum].U_Amount));

		if (Allocated > AllcAmt) {
			sap.m.MessageToast.show("Allocated amount is greater than the Grant Amount,please check..");
		}
	},

	onSearch: function(oEvt) {
		var list = sap.ui.getCore().byId("DonorListTable"); //this.getView().byId("idList");
		var oBinding = list.getBinding("items");
		// add filter for search
		var aFilters = [];
		var sQuery = oEvt.getSource().getValue();
		if (sQuery && sQuery.length > 0) {
			var filter = new sap.ui.model.Filter("CardName", sap.ui.model.FilterOperator.Contains, sQuery);
			aFilters.push(filter);
		}
		oBinding.filter(aFilters);
	}

	/**/

});