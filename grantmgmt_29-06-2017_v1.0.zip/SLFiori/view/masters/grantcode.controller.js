sap.ui.controller("SLFiori.view.masters.grantcode", {

	onInit: function() {
		this.router = sap.ui.core.UIComponent.getRouterFor(this);
		this.router.attachRoutePatternMatched(this._handleRouteMatched, this);
		
		this.NewEntry = {
			FormMode: "Add",
			PrcCode: "",
			PrcName: "",
			U_GrCu: "",
			U_Mangr: "",
			U_ExtText: "",
			U_GrRes: "",
			CurrCode:"",
			ComboRes: [{
				key: "U",
				value: "UnRestricted"
			}, {
				key: "R",
				value: "Restricted"
			}]
		};

		this.list = {
			FormMode: "Update",
	    	PrcCode: "",
			PrcName: "",
			U_GrCu: "",
			U_Mangr: "",
			U_ExtText: "",
			U_GrRes: "",
			CurrCode:"",
			ComboRes: [{
				key: "U",
				value: "UnRestricted"
			}, {
				key: "R",
				value: "Restricted"
			}]
		};

		this.oModel = new sap.ui.model.json.JSONModel(this.list);
		this.getView().setModel(this.oModel);
	},

	onAfterRendering: function() {
		//this.resetEmployeeObject();
	},
	
	handleSave: function(oEvent) {
		var oModelData = this.oModel.getData();

		var that = this;
		
		var jData = JSON.stringify({
			CenterCode: oModelData.PrcCode,
			CenterName:oModelData.PrcName,
			U_GrCur:oModelData.CurrCode,
			U_Mangr:oModelData.U_Mangr,
			U_ExtText:oModelData.U_ExtText,
			U_GrRes:oModelData.U_GrRes.key,
			EffectiveFrom: "2016-01-01",
			InWhichDimension: "1"
		});
		
		if (oModelData.FormMode !== "Add") {
			//sap.m.MessageToast.show("FormMode-Update");
			//this.GrantEntry=data.mParameters.arguments.Key;
			$.ajax({
				//url: "https://10.0.1.189:50000/b1s/v1/IK_GNCT(" + oModelData.GrantEntryNo + ")",
				url: "/b1s/v1/ProfitCenters('" + oModelData.PrcCode + "')",
				xhrFields: {
					withCredentials: true
				},
				data: jData,
				type: "PATCH",
				dataType: "json",
				success: function(json) {
					sap.m.MessageToast.show("Grant Code Updated Sucessfully");
				},
				error: function(xhr, status, errorThrown) {
					sap.m.MessageToast.show("Error: " + xhr.responseJSON.error.message.value);
				},
				complete: function(xhr, status) {}
			});

		} else {
			//sap.m.MessageToast.show("FormMode-Add");
			$.ajax({

				//url: "https://10.0.1.189:50000/b1s/v1/IK_GNCT",
				url: "/b1s/v1/ProfitCenters",
				xhrFields: {
					withCredentials: true
				},
				data: jData,
				type: "POST",
				dataType: "json",
				success: function(json) {
					sap.m.MessageToast.show("Grant Code Added Sucessfully");
				},
				error: function(xhr, status, errorThrown) {
					sap.m.MessageToast.show("Error: " + xhr.responseJSON.error.message.value);
				},
				complete: function(xhr, status) {}
			});
		}
	},
	
	_handleRouteMatched: function(data) {
		this.GrantCode = data.mParameters.arguments.Key;
		//this.SessionID = data.mParameters.arguments.Session;

		if (this.GrantCode === "0") {
			this.oModel = new sap.ui.model.json.JSONModel(this.NewEntry);
			this.getView().setModel(this.oModel);
		} else {
		    //this.byId("PrcCode").setEditable = false;
			var oParameter = data.getParameter("name");
			if (oParameter !== "masters.grantcode") {
				return;
			}
			var oModelData = this.oModel.getData();
			var that = this;
			$.ajax({
				//url: "/b1s/v1/ProfitCenters('" + this.GrantCode + "')?$select=CenterCode,CenterName,U_GrCur,U_Mangr,U_GrRes,U_ExtText",
				url: "OData/masters/grantcode/grantcode_header.xsodata/PrcCode?$filter=PrcCode eq '" + this.GrantCode + "'",
				xhrFields: {
					withCredentials: true
				},
				async: false,
				type: "GET",
				dataType: "json",
				success: function(oData, oResponse) {

					that.oModel.setProperty("/FormMode", "Update");
					that.oModel.setProperty("/PrcCode", oData.d.results[0].PrcCode);
					that.oModel.setProperty("/PrcName", oData.d.results[0].PrcName);
					that.oModel.setProperty("/CurrCode", oData.d.results[0].U_GrCur);
					that.oModel.setProperty("/U_GrCur", oData.d.results[0].U_GrCur);
					that.oModel.setProperty("/U_Mangr", oData.d.results[0].U_Mangr);
					that.oModel.setProperty("/U_ExtText", oData.d.results[0].U_ExtText);
					that.oModel.setProperty("/U_GrRes", oData.d.results[0].U_GrRes);

					that.oModel.refresh();
				},
				error: function(oError) {
					sap.m.MessageToast.show("Error: " + oError);
				}
			});
                
		}
	},

    onBack: function() {
		var that = this;
		that.router.navTo("Dashboard");
	},
	
	handleCurrency: function(oEvent) {
		var that = this;
		if (!this.oCurrencyrDialog) {
			this.oCurrencyrDialog = sap.ui.xmlfragment("SLFiori.fragments.CurrencyMasterV1", this);
		}
		sap.ui.getCore().byId("CurrencyListTable").removeSelections();
		this.oCurrencyrDialog.setModel(this.oModel);
		$.ajax({
			//url: "https://172.31.28.160:50000/b1s/v1/BusinessPartners?$select=CardCode,CardName,CntctPrsn,Cellular&$filter=CardType eq 'C'",
			//url: "https://172.31.28.160:50000/b1s/v1/BusinessPartners?$select=CardCode,CardName,ContactPerson,Cellular",
			//url: "http://10.0.1.189:8000/Ashoka/SAPUI5/WebContent/org/edu/ui/OData/GrantContract_Currencies.xsodata/Currency",
			url: "OData/GrantContract_Currencies.xsodata/Currency",
			xhrFields: {
				withCredentials: true
			},
			async: false,
			type: "GET",
			dataType: "json",
			success: function(oData, oResponse) {
				that.oModel.getData().CurrencyList = oData.d.results; //oData.value;
				that.oModel.refresh();
				that.oCurrencyrDialog.open();
			},
			error: function(oError) {
				sap.m.MessageToast.show("Error: " + oError.responseJSON.error.message.value);
			}
		});
	},

	handleCurrencyOk: function(oEvent) {
		var oDonorListTable = sap.ui.getCore().byId("CurrencyListTable");
		var oSelectedDonor = oDonorListTable.getSelectedItem();
		if (oSelectedDonor) {
			var oSelctedCustContext = oSelectedDonor.getBindingContext();
			var path = oSelctedCustContext.sPath;
			var Donor = this.oModel.getProperty(path);
			this.oModel.setProperty("/U_GrCur", Donor.CurrName);
			this.oModel.setProperty("/CurrCode", Donor.CurrCode);
			//this.oModel.setProperty("/DonorCnt", Donor.CntctPrsn);
			//this.oModel.setProperty("/TelNo", Donor.Cellular);

			this.oModel.refresh();
			sap.ui.getCore().byId("CurrencyListTable").removeSelections();
			this.oCurrencyrDialog.close();
		} else {
			sap.m.MessageToast.show("Please select Currency");
		}
	},

	handleCurrencyClose: function() {
		sap.ui.getCore().byId("CurrencyListTable").removeSelections();
		this.oCurrencyrDialog.close();
	}
});

