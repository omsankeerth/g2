sap.ui.controller("SLFiori.view.masters.programmaster", {

	onInit: function() {
		this.router = sap.ui.core.UIComponent.getRouterFor(this);
		this.router.attachRoutePatternMatched(this._handleRouteMatched, this);
		
		this.NewEntry = {
			FormMode: "Add",
			PrcCode: "",
			PrcName: "",
			U_ParPgm: "",
			U_Mangr: "",
			U_ExtText: "",
			U_GrRes: "",
			ComboRes: [{
				key: "U",
				value: "UnRestricted"
			}, {
				key: "R",
				value: "Restricted"
			}]
		};

		this.list = {
			FormMode: "Update",
	    	PrcCode: "",
			PrcName: "",
			U_ParPgm: "",
			U_Mangr: "",
			U_ExtText: "",
			U_GrRes: "",
			ComboRes: [{
				key: "U",
				value: "UnRestricted"
			}, {
				key: "R",
				value: "Restricted"
			}]
		};

		this.oModel = new sap.ui.model.json.JSONModel(this.list);
		this.getView().setModel(this.oModel);
	},

	onAfterRendering: function() {
		//this.resetEmployeeObject();
	},
	
	handleAdd: function(oEvent) {
		var GC = document.getElementById("idMain1--GCode-inner");
		var jData = JSON.stringify({
			U_IKGRCD: GC.value
		});
		$.ajax({
			url: "https://172.31.28.160:50000/b1s/v1/IKGRANTUDO",
			xhrFields: {
				withCredentials: true
			},
			data: jData,
			type: "POST",
			dataType: "json",
			success: function(json) {
				alert("Posting Success")
			},
			error: function(xhr, status, errorThrown) {
				alert(errorThrown);
			},
			complete: function(xhr, status) {}
		});
	},
	
	_handleRouteMatched: function(data) {
		this.ProgramCode = data.mParameters.arguments.Key;
		//this.SessionID = data.mParameters.arguments.Session;

		if (this.ProgramCode === "0") {
			this.oModel = new sap.ui.model.json.JSONModel(this.NewEntry);
			this.getView().setModel(this.oModel);
		} else {
			var oParameter = data.getParameter("name");
			if (oParameter !== "masters.programmaster") {
				return;
			}
			var oModelData = this.oModel.getData();
			var that = this;
			$.ajax({
				url: "/b1s/v1/ProfitCenters('" + this.ProgramCode + "')?$select=CenterCode,CenterName,U_ParPgm,U_Mangr,U_GrRes,U_ExtText",
				xhrFields: {
					withCredentials: true
				},
				async: false,
				type: "GET",
				dataType: "json",
				success: function(oData, oResponse) {

					that.oModel.setProperty("/FormMode", "Update");
					that.oModel.setProperty("/PrcCode", oData.CenterCode);
					that.oModel.setProperty("/PrcName", oData.CenterName);
					that.oModel.setProperty("/U_ParPgm", oData.U_ParPgm);
					that.oModel.setProperty("/U_Mangr", oData.U_Mangr);
					that.oModel.setProperty("/U_ExtText", oData.U_ExtText);
					that.oModel.setProperty("/U_GrRes", oData.U_GrRes);

					that.oModel.refresh();
				},
				error: function(oError) {
					sap.m.MessageToast.show("Error: " + oError);
				}
			});
                
		}
	},

    onBack: function() {
		var that = this;
		that.router.navTo("Dashboard");
	},
	
	handleSave: function(oEvent) {
		var oModelData = this.oModel.getData();

		var that = this;
		
		var jData = JSON.stringify({
			CenterCode: oModelData.PrcCode,
			CenterName:oModelData.PrcName,
			U_ParPgm:oModelData.U_ParPgm,
			U_Mangr:oModelData.U_Mangr,
			U_ExtText:oModelData.U_ExtText,
			U_GrRes:oModelData.U_GrRes.key,
			EffectiveFrom: "2016-01-01",
			InWhichDimension: "4"
		});
		
		if (oModelData.FormMode !== "Add") {
			//sap.m.MessageToast.show("FormMode-Update");
			//this.GrantEntry=data.mParameters.arguments.Key;
			$.ajax({
				//url: "https://10.0.1.189:50000/b1s/v1/IK_GNCT(" + oModelData.GrantEntryNo + ")",
				url: "/b1s/v1/ProfitCenters('" + oModelData.PrcCode + "')",
				xhrFields: {
					withCredentials: true
				},
				data: jData,
				type: "PATCH",
				dataType: "json",
				success: function(json) {
					sap.m.MessageToast.show("Program Master updated sucessfully");
				},
				error: function(xhr, status, errorThrown) {
					sap.m.MessageToast.show("Error: " + xhr.responseJSON.error.message.value);
				},
				complete: function(xhr, status) {}
			});

		} else {
			//sap.m.MessageToast.show("FormMode-Add");
			$.ajax({

				//url: "https://10.0.1.189:50000/b1s/v1/IK_GNCT",
				url: "/b1s/v1/ProfitCenters",
				xhrFields: {
					withCredentials: true
				},
				data: jData,
				type: "POST",
				dataType: "json",
				success: function(json) {
					sap.m.MessageToast.show("Program Master added sucessfully");
				},
				error: function(xhr, status, errorThrown) {
					sap.m.MessageToast.show("Error: " + xhr.responseJSON.error.message.value);
				},
				complete: function(xhr, status) {}
			});
		}
	}
});

